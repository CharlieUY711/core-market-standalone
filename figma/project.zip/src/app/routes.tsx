/* =====================================================
   Charlie Marketplace Builder — Router Config
   React Router v7 Data Mode
   ===================================================== */
import { createBrowserRouter } from 'react-router';

/* ── Auth ── */
import LoginPage     from './components/auth/LoginPage';
import ProtectedRoute from './components/auth/ProtectedRoute';

/* ── Etiqueta Emotiva — pública ── */
import MensajePage from './public/MensajePage';

/* ── Frontstore ODDY — público ── */
import OddyStorefront from './public/OddyStorefront';

/* ── Benefit Wheel — público ── */
import BenefitWheel from './public/BenefitWheel';

export const router = createBrowserRouter([

  /* ── Frontstore ODDY ─────────────────────────────── */
  {
    path: '/',
    Component: OddyStorefront,
  },

  /* ── Benefit Wheel ───────────────────────────────── */
  {
    path: '/ritual',
    Component: BenefitWheel,
  },

  /* ── Login / Registro ────────────────────────────── */
  {
    path: '/login',
    Component: LoginPage,
  },

  /* ── Panel Admin (protegido) ──────��──────────────── */
  {
    path: '/admin',
    Component: ProtectedRoute,
  },

  /* ── Etiqueta Emotiva — pública ──────────────────── */
  {
    path: '/m/:token',
    Component: MensajePage,
  },
]);