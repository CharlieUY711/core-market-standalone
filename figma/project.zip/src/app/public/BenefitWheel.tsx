/* =====================================================
   BenefitWheel — Sistema de Privilegio Mensual
   100% dinámico: consume Campaign Engine via backend
   Charlie Marketplace Builder v1.5
   ===================================================== */
import { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router';
import { projectId, publicAnonKey } from '/utils/supabase/info';

// ─── API ───────────────────────────────────────────────────────────────────────
const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-75638143`;
const H    = { 'Content-Type': 'application/json', Authorization: `Bearer ${publicAnonKey}` };

async function fetchActiveCampaign(type: 'gateway' | 'privilege') {
  const r = await fetch(`${BASE}/campaigns/active/${type}`, { headers: H });
  if (!r.ok) return null;
  return r.json();
}

async function spinCampaign(campaignId: string) {
  const r = await fetch(`${BASE}/campaigns/${campaignId}/spin`, { method: 'POST', headers: H });
  return r.json();
}

// ─── Types (shared with CampaignControlCenter) ────────────────────────────────
interface Reward {
  reward_id:             string;
  name:                  string;
  description:           string;
  icon:                  string;
  tier:                  'standard' | 'premium' | 'special';
  probability_weight:    number;
  stock_limit:           number;
  stock_remaining?:      number;
  cost_estimate:         number;
  requires_manual_review:boolean;
}
interface Campaign {
  id:                   string;
  name:                 string;
  campaign_type:        'gateway' | 'privilege';
  status:               string;
  next_activation_date: string | null;
  end_date:             string | null;
  theme_id:             string;
  rewards:              Reward[];
  economic:             { budget_limit: number; projected_cost: number };
}

// ─── Theme map ─────────────────────────────────────────────────────────────────
const THEMES: Record<string, { bg: string; accent: string }> = {
  dark_gold:       { bg: '#070708', accent: '#B89B55' },
  dark_silver:     { bg: '#080809', accent: '#A0A0A0' },
  midnight_blue:   { bg: '#06080F', accent: '#4A6FA5' },
  limited_edition: { bg: '#0A0705', accent: '#C98D45' },
};

// ─── Physics ───────────────────────────────────────────────────────────────────
const SPIN_ROTS  = 8;
const SPIN_DUR   = 4600;
const VIB_DUR    = 360;
const REVEAL_DUR = 1300;

function spinEase(t: number): number {
  if (t < 0.08) return Math.pow(t / 0.08, 2) * 0.05;
  if (t < 0.62) return 0.05 + ((t - 0.08) / 0.54) * 0.75;
  const d = (t - 0.62) / 0.38;
  return 0.80 + (1 - Math.pow(1 - d, 4)) * 0.20;
}

function tierColor(t: string, accent: string) {
  return t === 'special' ? '#C98D45' : t === 'premium' ? accent : '#7A7A7A';
}
function tierBg(t: string, accent: string) {
  return t === 'special' ? 'rgba(201,141,69,0.10)'
       : t === 'premium' ? accent.replace('#', 'rgba(') + ',0.10)' // fallback below
       : 'rgba(122,122,122,0.08)';
}
function segFill(i: number, tier: string): string {
  if (tier === 'special') return '#120F0A';
  if (tier === 'premium') return '#100E09';
  return i % 2 === 0 ? '#0A0A0B' : '#0D0D0E';
}

type Phase = 'loading' | 'no_campaign' | 'available' | 'spinning' | 'revealing' | 'claimed' | 'waiting';

// ─── History (mock per session) ───────────────────────────────────────────────
const SESSION_HISTORY: { icon: string; name: string; tier: string; month: string }[] = [];

// ─── Component ────────────────────────────────────────────────────────────────
export default function BenefitWheel() {
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const wrapRef     = useRef<HTMLDivElement>(null);
  const rotRef      = useRef(0);
  const sizeRef     = useRef(460);
  const rafRef      = useRef<number>();

  const [campaign,    setCampaign]    = useState<Campaign | null>(null);
  const [phase,       setPhase]       = useState<Phase>('loading');
  const [winnerIdx,   setWinnerIdx]   = useState<number | null>(null);
  const [winnerData,  setWinnerData]  = useState<Reward | null>(null);
  const [hlIdx,       setHlIdx]       = useState<number | null>(null);
  const [hlIntensity, setHlIntensity] = useState(0);
  const [btnPulse,    setBtnPulse]    = useState(false);
  const [history,     setHistory]     = useState([...SESSION_HISTORY]);
  const [countdown,   setCountdown]   = useState({ d: 0, h: 0, m: 0, s: 0 });
  const [spinError,   setSpinError]   = useState<string | null>(null);

  // Theme derived from campaign
  const theme = campaign ? (THEMES[campaign.theme_id] ?? THEMES.dark_gold) : THEMES.dark_gold;
  const G0     = theme.accent;
  const GA     = (a: number) => {
    // Parse hex to rgba
    const r = parseInt(G0.slice(1,3),16);
    const g = parseInt(G0.slice(3,5),16);
    const b = parseInt(G0.slice(5,7),16);
    return `rgba(${r},${g},${b},${a})`;
  };

  // ── Load campaign ───────────────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      const c = await fetchActiveCampaign('privilege');
      if (c && c.id) {
        setCampaign(c);
        setPhase('available');
      } else {
        setPhase('no_campaign');
      }
    })();
  }, []);

  // ── Draw ─────────────────────────────────────────────────────────────────────
  const draw = useCallback((
    rotation: number,
    highlight: number | null,
    intensity: number,
    rewards: Reward[],
    accent: string,
  ) => {
    const canvas = canvasRef.current;
    if (!canvas || !rewards.length) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const GA2 = (a: number) => {
      const r = parseInt(accent.slice(1,3),16);
      const g = parseInt(accent.slice(3,5),16);
      const b = parseInt(accent.slice(5,7),16);
      return `rgba(${r},${g},${b},${a})`;
    };

    const N   = rewards.length;
    const sz  = sizeRef.current;
    const cx  = sz / 2, cy = sz / 2;
    const outerR = sz * 0.452;
    const innerR = sz * 0.148;
    const midR   = (outerR + innerR) / 2;
    const segA   = (2 * Math.PI) / N;

    ctx.clearRect(0, 0, sz, sz);

    // Segments
    for (let i = 0; i < N; i++) {
      const startA = rotation + i * segA - Math.PI / 2;
      const endA   = startA + segA;
      const b      = rewards[i];
      const isHL   = i === highlight && intensity > 0;

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, outerR, startA, endA);
      ctx.closePath();
      if (isHL) {
        const grad = ctx.createRadialGradient(cx, cy, innerR * 0.6, cx, cy, outerR);
        grad.addColorStop(0,   `rgba(195,160,78,${0.28 * intensity})`);
        grad.addColorStop(0.55,`rgba(165,132,55,${0.13 * intensity})`);
        grad.addColorStop(1,   `rgba(100,78,25,${0.04 * intensity})`);
        ctx.fillStyle = grad;
      } else {
        ctx.fillStyle = segFill(i, b.tier);
      }
      ctx.fill();
      ctx.restore();

      // Separator
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(startA) * innerR, cy + Math.sin(startA) * innerR);
      ctx.lineTo(cx + Math.cos(startA) * outerR, cy + Math.sin(startA) * outerR);
      ctx.strokeStyle = GA2(0.20);
      ctx.lineWidth   = 0.75;
      ctx.stroke();
      ctx.restore();

      // Text
      const midAngle = startA + segA / 2;
      const tx = cx + Math.cos(midAngle) * midR;
      const ty = cy + Math.sin(midAngle) * midR;
      ctx.save();
      ctx.translate(tx, ty);
      ctx.rotate(midAngle + Math.PI / 2);
      const isHL2 = i === highlight && intensity > 0;
      ctx.fillStyle = isHL2
        ? `rgba(235,205,118,${0.55 + 0.45 * intensity})`
        : b.tier === 'special' ? `rgba(210,170,95,0.82)`
        : b.tier === 'premium' ? `rgba(200,172,115,0.82)`
        : `rgba(190,190,190,0.75)`;
      const fs = sz * 0.025;
      ctx.font         = `600 ${fs}px "DM Sans", system-ui, sans-serif`;
      ctx.textAlign    = 'center';
      ctx.textBaseline = 'middle';
      const lines = b.name.split(' ');
      lines.forEach((line, li) => {
        ctx.fillText(line, 0, (li - (lines.length - 1) / 2) * (fs * 1.32));
      });
      ctx.fillStyle = isHL2 ? `rgba(225,192,105,${0.65 * intensity})` : `rgba(150,150,150,0.38)`;
      ctx.font      = `${sz * 0.018}px system-ui, sans-serif`;
      ctx.fillText(b.description, 0, lines.length * fs * 0.74);
      ctx.restore();
    }

    // Outer ring
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, outerR, 0, 2 * Math.PI);
    ctx.strokeStyle = GA2(0.20);
    ctx.lineWidth   = 1;
    ctx.stroke();
    ctx.restore();

    // Tick marks
    const TICKS = 64;
    for (let t = 0; t < TICKS; t++) {
      const a      = rotation + (t / TICKS) * 2 * Math.PI - Math.PI / 2;
      const isMain = t % (TICKS / N) === 0;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * (outerR + 1), cy + Math.sin(a) * (outerR + 1));
      ctx.lineTo(cx + Math.cos(a) * (outerR + (isMain ? 10 : 5)), cy + Math.sin(a) * (outerR + (isMain ? 10 : 5)));
      ctx.strokeStyle = isMain ? GA2(0.48) : GA2(0.14);
      ctx.lineWidth   = isMain ? 1 : 0.5;
      ctx.stroke();
      ctx.restore();
    }

    // Outer ring 2
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, outerR + 14, 0, 2 * Math.PI);
    ctx.strokeStyle = GA2(0.07);
    ctx.lineWidth   = 1;
    ctx.stroke();
    ctx.restore();

    // Inner circle
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, innerR, 0, 2 * Math.PI);
    ctx.fillStyle = theme.bg;
    ctx.fill();
    ctx.strokeStyle = GA2(intensity > 0 ? 0.55 : 0.32);
    ctx.lineWidth   = 1;
    ctx.stroke();
    ctx.restore();

    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, innerR - 6, 0, 2 * Math.PI);
    ctx.strokeStyle = GA2(0.10);
    ctx.lineWidth   = 0.5;
    ctx.stroke();
    ctx.restore();

    // Pointer
    const pCy = cy - outerR - 14;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(cx, pCy + 3);
    ctx.lineTo(cx - 7, pCy - 9);
    ctx.lineTo(cx + 7, pCy - 9);
    ctx.closePath();
    ctx.fillStyle   = accent;
    ctx.shadowColor = accent;
    ctx.shadowBlur  = 8;
    ctx.fill();
    ctx.restore();
  }, [theme.bg]);

  // ── Canvas init ───────────────────────────────────────────────────────────────
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap   = wrapRef.current;
    if (!canvas || !wrap || !campaign) return;
    const raw  = Math.min(wrap.clientWidth || 460, 460);
    const sz   = raw > 60 ? raw : 460;
    const dpr  = window.devicePixelRatio || 1;
    sizeRef.current = sz;
    canvas.width        = sz * dpr;
    canvas.height       = sz * dpr;
    canvas.style.width  = `${sz}px`;
    canvas.style.height = `${sz}px`;
    canvas.getContext('2d')!.scale(dpr, dpr);
    draw(rotRef.current, null, 0, campaign.rewards, G0);
  }, [campaign, draw, G0]);

  // Redraw on phase/hl change
  useEffect(() => {
    if (!campaign) return;
    if (phase === 'available' || phase === 'waiting') draw(rotRef.current, null, 0, campaign.rewards, G0);
  }, [phase, campaign, draw, G0]);

  // Pulse button
  useEffect(() => {
    if (phase !== 'available') { setBtnPulse(false); return; }
    const id = setTimeout(() => setBtnPulse(true), 800);
    return () => clearTimeout(id);
  }, [phase]);

  // Countdown (waiting)
  useEffect(() => {
    if (phase !== 'waiting') return;
    const nextDate = campaign?.next_activation_date || campaign?.end_date;
    if (!nextDate) return;
    const target = new Date(nextDate).getTime();
    const id = setInterval(() => {
      const diff = target - Date.now();
      if (diff <= 0) { clearInterval(id); return; }
      setCountdown({
        d: Math.floor(diff / 86400000),
        h: Math.floor((diff % 86400000) / 3600000),
        m: Math.floor((diff % 3600000) / 60000),
        s: Math.floor((diff % 60000) / 1000),
      });
    }, 1000);
    return () => clearInterval(id);
  }, [phase, campaign]);

  // ── Spin ─────────────────────────────────────────────────────────────────────
  const handleActivate = useCallback(async () => {
    if (phase !== 'available' || !campaign) return;
    setSpinError(null);
    setPhase('spinning');
    setBtnPulse(false);

    // Call backend activation engine
    const result = await spinCampaign(campaign.id);
    if (!result || result.error) {
      setSpinError(result?.error ?? 'Error al activar');
      setPhase('available');
      return;
    }

    const winner      = result.winner as Reward;
    const winnerIndex = result.winner_index as number;
    const rewards     = campaign.rewards;
    const N           = rewards.length;
    const segA        = (2 * Math.PI) / N;
    const startR      = rotRef.current;

    setWinnerIdx(winnerIndex);
    setWinnerData(winner);

    const targetR  = Math.PI / 2 - winnerIndex * segA - segA / 2;
    const sNorm    = ((startR % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
    const tNorm    = ((targetR % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
    let delta      = tNorm - sNorm;
    if (delta <= 0) delta += 2 * Math.PI;
    const total    = SPIN_ROTS * 2 * Math.PI + delta;
    const t0       = performance.now();

    const animate = (now: number) => {
      const t        = Math.min((now - t0) / SPIN_DUR, 1);
      const progress = spinEase(t);
      const rot      = startR + total * progress;
      rotRef.current = rot;
      draw(rot, null, 0, rewards, G0);
      if (t < 1) {
        rafRef.current = requestAnimationFrame(animate);
      } else {
        const finalRot = startR + total;
        rotRef.current = finalRot;
        const v0 = performance.now();
        const vibrate = (now2: number) => {
          const vt  = Math.min((now2 - v0) / VIB_DUR, 1);
          const vib = 0.016 * Math.sin(vt * 48) * Math.exp(-vt * 11);
          draw(finalRot + vib, null, 0, rewards, G0);
          if (vt < 1) {
            rafRef.current = requestAnimationFrame(vibrate);
          } else {
            setPhase('revealing');
            setHlIdx(winnerIndex);
            const r0 = performance.now();
            const reveal = (now3: number) => {
              const rt        = Math.min((now3 - r0) / REVEAL_DUR, 1);
              const intensity = 1 - Math.pow(1 - rt, 3);
              setHlIntensity(intensity);
              draw(finalRot, winnerIndex, intensity, rewards, G0);
              if (rt < 1) {
                rafRef.current = requestAnimationFrame(reveal);
              } else {
                setHlIntensity(1);
                setPhase('claimed');
                // Update local history
                setHistory(prev => [
                  { icon: winner.icon, name: winner.name, tier: winner.tier, month: new Date().toLocaleDateString('es-AR', { month:'short', year:'2-digit' }) },
                  ...prev,
                ].slice(0, 5));
              }
            };
            rafRef.current = requestAnimationFrame(reveal);
          }
        };
        rafRef.current = requestAnimationFrame(vibrate);
      }
    };
    rafRef.current = requestAnimationFrame(animate);
  }, [phase, campaign, draw, G0]);

  const handleReset = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    setPhase('waiting');
    setWinnerIdx(null);
    setWinnerData(null);
    setHlIdx(null);
    setHlIntensity(0);
    rotRef.current = 0;
    if (campaign) draw(0, null, 0, campaign.rewards, G0);
  }, [campaign, draw, G0]);

  const isSpinning = phase === 'spinning' || phase === 'revealing';
  const PAGE_BG    = theme.bg;
  const TAGLINES   = ['Beneficio activado', 'Acceso desbloqueado', 'Edición disponible'];
  const tagline    = winnerData ? TAGLINES[winnerIdx! % 3] : '';

  // ─── Render ──────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight:'100vh', background:PAGE_BG, color:'#D4D4D4', fontFamily:'"DM Sans",system-ui,sans-serif', overflowX:'hidden' }}>

      {/* Top bar */}
      <header style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'18px 32px', borderBottom:'1px solid rgba(255,255,255,0.04)' }}>
        <Link to="/" style={{ fontFamily:'"Bebas Neue",sans-serif', fontSize:'1.4rem', letterSpacing:'0.12em', color:'#E0E0E0', textDecoration:'none' }}>ODDY</Link>
        <div style={{ display:'flex', alignItems:'center', gap:'12px' }}>
          <span style={{ fontSize:'0.68rem', letterSpacing:'0.18em', color:GA(0.65), textTransform:'uppercase', fontWeight:600 }}>
            {campaign ? campaign.name : 'Sistema de Privilegios'}
          </span>
          <div style={{ width:'1px', height:'14px', background:'rgba(255,255,255,0.08)' }}/>
          <span style={{ fontSize:'0.68rem', color:'rgba(180,180,180,0.45)', letterSpacing:'0.06em' }}>
            {campaign?.campaign_type === 'privilege' ? 'Acceso Mensual Exclusivo' : 'Acceso Público'}
          </span>
        </div>
        <div style={{ width:'70px' }}/>
      </header>

      {/* Loading / no campaign */}
      {phase === 'loading' && (
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'80vh', flexDirection:'column', gap:'16px' }}>
          <div style={{ width:'40px', height:'40px', border:`2px solid ${GA(0.2)}`, borderTopColor:G0, borderRadius:'50%', animation:'spin 0.8s linear infinite' }}/>
          <p style={{ color:GA(0.5), fontSize:'0.8rem', letterSpacing:'0.1em' }}>Cargando campaña...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {phase === 'no_campaign' && (
        <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'80vh', flexDirection:'column', gap:'16px', textAlign:'center' }}>
          <div style={{ fontSize:'3rem', opacity:0.3 }}>◆</div>
          <h2 style={{ color:'#E0E0E0', fontFamily:'"Bebas Neue",sans-serif', letterSpacing:'0.1em' }}>SIN CAMPAÑA ACTIVA</h2>
          <p style={{ color:'rgba(180,180,180,0.4)', fontSize:'0.82rem', maxWidth:'340px' }}>
            No hay ninguna campaña Privilege activa en este momento. Configurala desde el panel de administración.
          </p>
          <Link to="/admin" style={{ marginTop:'8px', padding:'10px 24px', background:G0, color:'#000', borderRadius:'4px', textDecoration:'none', fontSize:'0.78rem', fontWeight:700, letterSpacing:'0.1em' }}>
            Ir al Admin
          </Link>
        </div>
      )}

      {/* Main layout */}
      {campaign && phase !== 'loading' && phase !== 'no_campaign' && (
        <div style={{ display:'grid', gridTemplateColumns:'minmax(0,1fr) minmax(0,320px)', maxWidth:'1100px', margin:'0 auto', padding:'0 24px', gap:'40px', alignItems:'start' }}>

          {/* Left: wheel */}
          <div style={{ paddingTop:'48px', paddingBottom:'60px' }}>
            {/* Edition pill */}
            <div style={{ display:'inline-flex', alignItems:'center', gap:'8px', padding:'5px 14px', border:`1px solid ${GA(0.22)}`, borderRadius:'2px', marginBottom:'24px' }}>
              <div style={{ width:'5px', height:'5px', borderRadius:'50%', background:G0, boxShadow:`0 0 6px ${GA(0.7)}` }}/>
              <span style={{ fontSize:'0.65rem', letterSpacing:'0.2em', color:GA(0.65), textTransform:'uppercase', fontWeight:700 }}>
                {campaign.campaign_type === 'privilege' ? 'Privilegio Mensual' : 'Gateway'} · {campaign.name}
              </span>
            </div>

            <h1 style={{ fontFamily:'"Bebas Neue",sans-serif', fontSize:'clamp(2.8rem,5vw,4.2rem)', letterSpacing:'0.06em', color:'#EBEBEB', lineHeight:1.0, marginBottom:'14px' }}>
              TU BENEFICIO<br/><span style={{ color:G0 }}>EXCLUSIVO</span>
            </h1>
            <p style={{ fontSize:'0.88rem', color:'rgba(180,180,180,0.55)', lineHeight:1.7, maxWidth:'380px', marginBottom:'44px', letterSpacing:'0.02em' }}>
              Cada edición activa un acceso diferente.<br/>Este es tu momento del mes.
            </p>

            {spinError && (
              <div style={{ marginBottom:'16px', padding:'10px 14px', background:'rgba(220,38,38,0.10)', border:'1px solid rgba(220,38,38,0.25)', borderRadius:'4px', fontSize:'0.78rem', color:'#F87171' }}>
                {spinError}
              </div>
            )}

            {/* Wheel container */}
            <div ref={wrapRef} style={{ position:'relative', width:'100%', maxWidth:'460px', margin:'0 auto' }}>
              <canvas ref={canvasRef} style={{ display:'block' }}/>

              {/* Center overlay */}
              {phase === 'available' && (
                <button onClick={handleActivate}
                  style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)',
                    width:`${sizeRef.current * 0.296}px`, height:`${sizeRef.current * 0.296}px`,
                    borderRadius:'50%', background:'transparent', border:'none', cursor:'pointer',
                    display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                    animation: btnPulse ? 'wheelPulse 2.4s ease-in-out infinite' : 'none' }}>
                  <span style={{ fontSize:'0.6rem', letterSpacing:'0.22em', color:G0, fontWeight:700, textTransform:'uppercase' }}>Activar</span>
                </button>
              )}
              {phase === 'spinning' && (
                <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', display:'flex', gap:'5px', alignItems:'center' }}>
                  {[0,1,2].map(i => (
                    <div key={i} style={{ width:'4px', height:'4px', borderRadius:'50%', background:GA(0.6), animation:`spinDot 0.9s ease-in-out ${i*0.18}s infinite` }}/>
                  ))}
                </div>
              )}
              {(phase === 'revealing' || phase === 'claimed') && winnerData && (
                <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', display:'flex', flexDirection:'column', alignItems:'center', gap:'2px', opacity:hlIntensity, transition:'opacity 0.2s', pointerEvents:'none' }}>
                  <span style={{ fontSize:`${sizeRef.current * 0.042}px`, color:G0, lineHeight:1 }}>{winnerData.icon}</span>
                  <span style={{ fontSize:'0.48rem', letterSpacing:'0.2em', color:GA(0.8), fontWeight:700, textTransform:'uppercase' }}>Activo</span>
                </div>
              )}
              {phase === 'waiting' && (
                <div style={{ position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)', display:'flex', flexDirection:'column', alignItems:'center', pointerEvents:'none' }}>
                  <span style={{ fontSize:'0.5rem', letterSpacing:'0.18em', color:'rgba(180,180,180,0.3)', textTransform:'uppercase', fontWeight:600 }}>próxima</span>
                  <span style={{ fontSize:'0.5rem', letterSpacing:'0.18em', color:'rgba(180,180,180,0.3)', textTransform:'uppercase', fontWeight:600 }}>edición</span>
                </div>
              )}
            </div>

            {/* Status */}
            <div style={{ textAlign:'center', maxWidth:'460px', margin:'28px auto 0' }}>
              {phase === 'available' && <p style={{ fontSize:'0.78rem', color:'rgba(180,180,180,0.45)', letterSpacing:'0.06em' }}>Presioná el centro para activar tu beneficio de esta edición</p>}
              {isSpinning && <p style={{ fontSize:'0.78rem', color:GA(0.5), letterSpacing:'0.08em', fontStyle:'italic' }}>Determinando acceso...</p>}
              {phase === 'claimed' && winnerData && (
                <div>
                  <div style={{ display:'inline-flex', alignItems:'center', gap:'10px', padding:'10px 22px', border:`1px solid ${GA(0.30)}`, borderRadius:'3px', background:`rgba(184,155,85,0.05)`, marginBottom:'10px' }}>
                    <span style={{ fontSize:'1.1rem', color:G0 }}>{winnerData.icon}</span>
                    <div style={{ textAlign:'left' }}>
                      <div style={{ fontSize:'0.62rem', letterSpacing:'0.18em', color:GA(0.65), textTransform:'uppercase', fontWeight:700, marginBottom:'2px' }}>{tagline}</div>
                      <div style={{ fontSize:'0.9rem', color:'#E0E0E0', fontWeight:600 }}>{winnerData.name}</div>
                      <div style={{ fontSize:'0.72rem', color:'rgba(180,180,180,0.5)' }}>{winnerData.description}</div>
                    </div>
                  </div>
                  <div style={{ fontSize:'0.7rem', color:'rgba(160,160,160,0.4)', letterSpacing:'0.06em' }}>
                    {campaign.end_date ? `Disponible hasta ${campaign.end_date}` : 'Acceso disponible'} · Código enviado a tu correo
                  </div>
                </div>
              )}
              {phase === 'waiting' && <p style={{ fontSize:'0.78rem', color:'rgba(160,160,160,0.4)', letterSpacing:'0.06em' }}>Próxima activación disponible en la siguiente edición</p>}
            </div>

            {/* Countdown */}
            {(phase === 'claimed' || phase === 'waiting') && (
              <div style={{ display:'flex', justifyContent:'center', marginTop:'24px', maxWidth:'460px', margin:'24px auto 0' }}>
                {[{v:String(countdown.d).padStart(2,'0'),l:'días'},{v:String(countdown.h).padStart(2,'0'),l:'horas'},{v:String(countdown.m).padStart(2,'0'),l:'min'},{v:String(countdown.s).padStart(2,'0'),l:'seg'}].map((u,i)=>(
                  <div key={i} style={{ display:'flex', alignItems:'center' }}>
                    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', padding:'10px 14px', background:'rgba(255,255,255,0.02)', border:'1px solid rgba(255,255,255,0.05)' }}>
                      <span style={{ fontFamily:'"JetBrains Mono",monospace', fontSize:'1.4rem', color:'#C8C8C8', fontWeight:600, lineHeight:1 }}>{u.v}</span>
                      <span style={{ fontSize:'0.56rem', letterSpacing:'0.14em', color:'rgba(180,180,180,0.35)', textTransform:'uppercase', marginTop:'4px' }}>{u.l}</span>
                    </div>
                    {i<3 && <span style={{ padding:'0 4px', color:'rgba(180,180,180,0.20)', fontFamily:'monospace', fontSize:'1.2rem' }}>:</span>}
                  </div>
                ))}
              </div>
            )}

            {phase === 'claimed' && (
              <div style={{ textAlign:'center', marginTop:'16px' }}>
                <button onClick={handleReset} style={{ background:'none', border:'none', color:'rgba(180,180,180,0.25)', fontSize:'0.65rem', letterSpacing:'0.12em', cursor:'pointer', textTransform:'uppercase' }}>
                  Nueva edición ↺
                </button>
              </div>
            )}
          </div>

          {/* Right panel */}
          <div style={{ paddingTop:'48px', paddingBottom:'60px', display:'flex', flexDirection:'column', gap:'20px' }}>

            {/* Historial */}
            <Panel title="Tu Historial" accent={G0} GA={GA}>
              {history.length === 0 ? (
                <p style={{ fontSize:'0.75rem', color:'rgba(160,160,160,0.35)', textAlign:'center', padding:'16px 0' }}>Sin activaciones previas en esta sesión</p>
              ) : (
                <div style={{ display:'flex', flexDirection:'column', gap:'2px' }}>
                  {history.map((h, i) => (
                    <div key={i} style={{ display:'flex', alignItems:'center', gap:'12px', padding:'8px 10px', borderRadius:'3px', background: i===0 ? GA(0.05) : 'transparent' }}>
                      <span style={{ fontSize:'0.9rem', color:tierColor(h.tier, G0), width:'18px', textAlign:'center' }}>{h.icon}</span>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:'0.8rem', color:'#C8C8C8', fontWeight:500 }}>{h.name}</div>
                        <div style={{ fontSize:'0.65rem', color:'rgba(160,160,160,0.4)' }}>{h.month}</div>
                      </div>
                      <span style={{ fontSize:'0.6rem', padding:'2px 8px', borderRadius:'2px', background:tierBg(h.tier, G0), color:tierColor(h.tier, G0), fontWeight:700, textTransform:'uppercase' }}>{h.tier}</span>
                    </div>
                  ))}
                </div>
              )}
            </Panel>

            {/* Rewards de esta campaña */}
            <Panel title={`Edición ${campaign.name}`} accent={G0} GA={GA} subtitle={`${campaign.rewards.length} accesos posibles`}>
              <div style={{ display:'flex', flexDirection:'column', gap:'2px' }}>
                {campaign.rewards.map((r, i) => (
                  <div key={r.reward_id || i} style={{ display:'flex', alignItems:'center', gap:'10px', padding:'6px 8px', borderRadius:'2px' }}>
                    <span style={{ fontSize:'0.78rem', color:tierColor(r.tier, G0), width:'14px', textAlign:'center', flexShrink:0 }}>{r.icon}</span>
                    <span style={{ fontSize:'0.76rem', color:'rgba(190,190,190,0.65)' }}>{r.name}</span>
                    {r.tier !== 'standard' && (
                      <span style={{ marginLeft:'auto', fontSize:'0.55rem', padding:'1px 7px', borderRadius:'2px', background:tierBg(r.tier, G0), color:tierColor(r.tier, G0), fontWeight:700, textTransform:'uppercase', flexShrink:0 }}>{r.tier}</span>
                    )}
                  </div>
                ))}
              </div>
            </Panel>

            {/* Economic transparency */}
            <Panel title="Transparencia" accent={G0} GA={GA} subtitle="Indicadores de esta edición">
              <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:'1px', background:'rgba(255,255,255,0.04)', borderRadius:'3px', overflow:'hidden', marginBottom:'14px' }}>
                {[
                  { v: campaign.rewards.length.toString(), l:'Beneficios' },
                  { v: `${Math.round((campaign.economic?.projected_cost??0)/(campaign.economic?.budget_limit||5000)*100)}%`, l:'Utilización' },
                ].map((s,i) => (
                  <div key={i} style={{ padding:'12px 10px', textAlign:'center', background:'#0D0D0E' }}>
                    <div style={{ fontFamily:'"JetBrains Mono",monospace', fontSize:'1.1rem', color:'#CCCCCC', fontWeight:600, lineHeight:1 }}>{s.v}</div>
                    <div style={{ fontSize:'0.6rem', color:'rgba(160,160,160,0.4)', marginTop:'4px', letterSpacing:'0.06em' }}>{s.l}</div>
                  </div>
                ))}
              </div>
              <div style={{ fontSize:'0.62rem', color:'rgba(160,160,160,0.3)', lineHeight:1.6 }}>
                El resultado se determina en el servidor antes del giro. Motor de activación certificado. Nada depende del cliente.
              </div>
            </Panel>
          </div>
        </div>
      )}

      {/* Bottom */}
      <div style={{ borderTop:'1px solid rgba(255,255,255,0.04)', padding:'14px 32px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <span style={{ fontSize:'0.62rem', color:'rgba(160,160,160,0.25)', letterSpacing:'0.08em' }}>
          Resultado determinado por backend antes del giro. Sistema de privilegio, no de azar.
        </span>
        <span style={{ fontSize:'0.62rem', color:'rgba(160,160,160,0.25)', letterSpacing:'0.08em' }}>
          ODDY PRIVILEGE SYSTEM · v2.5 · Campaign Engine
        </span>
      </div>

      <style>{`
        @keyframes wheelPulse { 0%,100% { box-shadow:0 0 0 0 rgba(184,155,85,0); } 50% { box-shadow:0 0 18px 6px rgba(184,155,85,0.12); } }
        @keyframes spinDot    { 0%,80%,100% { opacity:.15; transform:scale(.8); } 40% { opacity:1; transform:scale(1.2); } }
      `}</style>
    </div>
  );
}

// ─── Panel wrapper ────────────────────────────────────────────────────────────
function Panel({ title, subtitle, accent, GA, children }: {
  title: string; subtitle?: string; accent: string; GA: (a:number)=>string; children: React.ReactNode;
}) {
  return (
    <div style={{ border:'1px solid rgba(255,255,255,0.055)', borderRadius:'4px', background:'rgba(255,255,255,0.014)', overflow:'hidden' }}>
      <div style={{ padding:'14px 16px 12px', borderBottom:'1px solid rgba(255,255,255,0.04)', display:'flex', alignItems:'baseline', gap:'10px' }}>
        <span style={{ fontSize:'0.68rem', letterSpacing:'0.16em', color:'rgba(200,200,200,0.55)', textTransform:'uppercase', fontWeight:700 }}>{title}</span>
        {subtitle && <span style={{ fontSize:'0.62rem', color:'rgba(160,160,160,0.3)' }}>{subtitle}</span>}
      </div>
      <div style={{ padding:'12px' }}>{children}</div>
    </div>
  );
}
