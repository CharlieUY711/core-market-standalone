/* =====================================================
   charlie.ts — Helpers tipados del charlie.config.json
   ===================================================== */
import config from '../../../charlie.config.json';

export interface BrandingConfig {
  storeName: string;
  tagline: string;
  currency: string;
  primaryColor: string;
  secondaryColor: string;
  bgColor: string;
}

export interface PageConfig {
  id: string;
  path: string;
  enabled: boolean;
}

export interface SectionConfig {
  id: string;
  enabled: boolean;
}

export type LayoutVariant = 'default' | 'secondhand' | 'marketplace' | 'b2b';

export const branding: BrandingConfig = config.frontstore.branding;

export const enabledPages: PageConfig[] = config.frontstore.pages.filter(
  (p) => p.enabled,
);

export const enabledSections: SectionConfig[] = config.frontstore.home.sections.filter(
  (s) => s.enabled,
);

export const activeModules: string[] = config.modules;

export const hasModule = (id: string): boolean => activeModules.includes(id);

export const layoutVariant = (): LayoutVariant => {
  if (hasModule('secondhand') || hasModule('second-hand')) return 'secondhand';
  if (hasModule('departamentos') || activeModules.length > 6) return 'marketplace';
  if (hasModule('erp-compras') || hasModule('erp-facturacion')) return 'b2b';
  return 'default';
};

export const formatCurrency = (amount: number): string => {
  const symbols: Record<string, string> = {
    USD: 'US$', ARS: '$', UYU: '$U', CLP: '$', BRL: 'R$', MXN: '$', EUR: '€',
  };
  const sym = symbols[branding.currency] ?? '$';
  return `${sym} ${amount.toLocaleString('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};
