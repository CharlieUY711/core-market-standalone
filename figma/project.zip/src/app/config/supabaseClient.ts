/* =====================================================
   supabaseClient — Singleton del cliente Supabase
   para el frontstore público (ODDY)
   ===================================================== */
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';

let _client: SupabaseClient | null = null;

export const getSupabase = (): SupabaseClient => {
  if (!_client) {
    _client = createClient(
      `https://${projectId}.supabase.co`,
      publicAnonKey,
    );
  }
  return _client;
};
