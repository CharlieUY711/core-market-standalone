/* =====================================================
   AuthContext — Estado de sesión con Supabase Auth
   Charlie Marketplace Builder v1.5
   ===================================================== */
import React, { createContext, useContext, useEffect, useState } from 'react';
import { createClient, SupabaseClient, User, Session } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';

// ── Singleton Supabase client ──────────────────────────────────────
let _supabase: SupabaseClient | null = null;
export const getSupabase = (): SupabaseClient => {
  if (!_supabase) {
    _supabase = createClient(`https://${projectId}.supabase.co`, publicAnonKey);
  }
  return _supabase;
};

// ── Types ──────────────────────────────────────────────────────────
interface AuthContextType {
  user:    User    | null;
  session: Session | null;
  loading: boolean;
  signIn:        (email: string, password: string) => Promise<{ error: string | null }>;
  signUp:        (email: string, password: string, name: string) => Promise<{ error: string | null }>;
  signOut:       () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextType | null>(null);

// ── Provider ───────────────────────────────────────────────────────
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user,    setUser]    = useState<User    | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const sb = getSupabase();

    // 1. Sesión existente al montar
    sb.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // 2. Escuchar cambios de auth (login, logout, refresh token)
    const { data: { subscription } } = sb.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // ── signIn ────────────────────────────────────────────────────────
  const signIn = async (email: string, password: string): Promise<{ error: string | null }> => {
    try {
      const { error } = await getSupabase().auth.signInWithPassword({ email, password });
      if (error) {
        if (error.message?.includes('Invalid login credentials')) {
          return { error: 'Email o contraseña incorrectos.' };
        }
        return { error: error.message };
      }
      return { error: null };
    } catch (e: any) {
      return { error: `Error de conexión: ${e.message}` };
    }
  };

  // ── signUp (vía backend con email_confirm: true) ──────────────────
  const signUp = async (email: string, password: string, name: string): Promise<{ error: string | null }> => {
    try {
      const res = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-75638143/auth/signup`,
        {
          method:  'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${publicAnonKey}` },
          body:    JSON.stringify({ email, password, name }),
        }
      );
      const data = await res.json();
      if (!res.ok) return { error: data.error || 'Error al registrar usuario.' };

      // Iniciar sesión automáticamente tras el registro
      return signIn(email, password);
    } catch (e: any) {
      return { error: `Error de conexión: ${e.message}` };
    }
  };

  // ── signOut ───────────────────────────────────────────────────────
  const signOut = async () => {
    await getSupabase().auth.signOut();
  };

  // ── resetPassword ─────────────────────────────────────────────────
  const resetPassword = async (email: string): Promise<{ error: string | null }> => {
    const { error } = await getSupabase().auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/login`,
    });
    return { error: error?.message ?? null };
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, signIn, signUp, signOut, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
}

// ── Hook ───────────────────────────────────────────────────────────
export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth debe usarse dentro de <AuthProvider>');
  return ctx;
}

// ── Helper: obtener nombre/iniciales del usuario ──────────────────
export function getUserDisplayName(user: User | null): string {
  if (!user) return 'Invitado';
  return (
    user.user_metadata?.name ||
    user.user_metadata?.full_name ||
    user.email?.split('@')[0] ||
    'Usuario'
  );
}

export function getUserInitials(user: User | null): string {
  const name = getUserDisplayName(user);
  const parts = name.trim().split(' ');
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return name.slice(0, 2).toUpperCase();
}
