/* =====================================================
   ProtectedRoute — Guarda rutas privadas
   Redirige a /login si no hay sesión activa
   Charlie Marketplace Builder v1.5
   ===================================================== */
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Loader2 } from 'lucide-react';
import { useAuth } from './AuthContext';
import AdminDashboard from '../../AdminDashboard';

const ORANGE = '#FF6835';

export default function ProtectedRoute() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate('/login', { replace: true });
    }
  }, [user, loading, navigate]);

  // Mientras se verifica la sesión
  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '16px',
        backgroundColor: '#F8F9FA',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
      }}>
        <div style={{
          width: '52px', height: '52px', borderRadius: '14px',
          backgroundColor: ORANGE,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <span style={{ color: '#000', fontWeight: '900', fontSize: '1.1rem', letterSpacing: '-0.02em' }}>C</span>
        </div>
        <Loader2 size={22} color={ORANGE} style={{ animation: 'spin 1s linear infinite' }} />
        <p style={{ margin: 0, fontSize: '0.82rem', color: '#6B7280' }}>Verificando sesión…</p>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  // No autenticado → useEffect redirige; mientras tanto no renderizar nada
  if (!user) return null;

  return <AdminDashboard />;
}
