/* =====================================================
   LoginPage — Pantalla de acceso a Charlie
   Split: panel naranja + formulario blanco
   Charlie Marketplace Builder v1.5
   ===================================================== */
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import {
  Eye, EyeOff, Mail, Lock, User, ArrowRight,
  AlertCircle, CheckCircle2, ChevronLeft, Loader2,
} from 'lucide-react';
import { useAuth } from './AuthContext';

const ORANGE = '#FF6835';
const DARK   = '#1A1814';

type Mode = 'login' | 'register' | 'reset';

// ── Panel izquierdo — branding ─────────────────────────────────────
function BrandPanel() {
  const features = [
    { icon: '🛒', label: 'eCommerce completo',      sub: 'Catálogo, pedidos, pagos' },
    { icon: '📦', label: 'Logística integrada',      sub: 'Envíos, tracking, rutas'  },
    { icon: '📊', label: 'ERP y gestión',            sub: 'Inventario, facturación'  },
    { icon: '🚀', label: 'Constructor de tiendas',   sub: 'Deploy en minutos'        },
  ];

  return (
    <div style={{
      width: '42%',
      flexShrink: 0,
      backgroundColor: ORANGE,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      padding: '48px 40px',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Decoración de fondo */}
      <div style={{
        position: 'absolute',
        top: '-60px', right: '-60px',
        width: '280px', height: '280px',
        borderRadius: '50%',
        backgroundColor: 'rgba(0,0,0,0.08)',
        pointerEvents: 'none',
      }} />
      <div style={{
        position: 'absolute',
        bottom: '-80px', left: '-40px',
        width: '320px', height: '320px',
        borderRadius: '50%',
        backgroundColor: 'rgba(0,0,0,0.06)',
        pointerEvents: 'none',
      }} />

      {/* Logo */}
      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ marginBottom: '6px' }}>
          <span style={{
            fontSize: '3rem',
            fontWeight: '900',
            color: '#000',
            letterSpacing: '-0.02em',
            lineHeight: 1,
            display: 'block',
          }}>
            Charlie
          </span>
          <span style={{
            fontSize: '0.72rem',
            fontWeight: '700',
            color: 'rgba(0,0,0,0.55)',
            letterSpacing: '0.14em',
            textTransform: 'uppercase',
          }}>
            Marketplace Builder
          </span>
        </div>
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px',
          backgroundColor: 'rgba(0,0,0,0.12)',
          borderRadius: '20px',
          padding: '3px 10px 3px 8px',
          marginTop: '10px',
        }}>
          <div style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#000' }} />
          <span style={{ fontSize: '0.68rem', fontWeight: '700', color: '#000', letterSpacing: '0.08em' }}>
            v1.5 — Multi-tenant
          </span>
        </div>
      </div>

      {/* Tagline central */}
      <div style={{ position: 'relative', zIndex: 1 }}>
        <h2 style={{
          margin: '0 0 12px',
          fontSize: '1.9rem',
          fontWeight: '900',
          color: '#000',
          lineHeight: 1.15,
          letterSpacing: '-0.01em',
        }}>
          Tu plataforma<br />empresarial<br />todo-en-uno
        </h2>
        <p style={{
          margin: 0,
          fontSize: '0.85rem',
          color: 'rgba(0,0,0,0.6)',
          lineHeight: 1.6,
          maxWidth: '260px',
        }}>
          Gestioná tu marketplace, logística y equipo desde un solo lugar.
        </p>
      </div>

      {/* Feature list */}
      <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {features.map(f => (
          <div key={f.label} style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: '10px 14px',
            backgroundColor: 'rgba(0,0,0,0.10)',
            borderRadius: '12px',
            backdropFilter: 'blur(4px)',
          }}>
            <span style={{ fontSize: '1.1rem', flexShrink: 0 }}>{f.icon}</span>
            <div>
              <p style={{ margin: 0, fontSize: '0.8rem', fontWeight: '700', color: '#000' }}>{f.label}</p>
              <p style={{ margin: 0, fontSize: '0.7rem', color: 'rgba(0,0,0,0.55)' }}>{f.sub}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Input field ────────────────────────────────────────────────────
function Field({
  label, type = 'text', value, onChange, placeholder, icon: Icon,
  rightElement, error, autoFocus,
}: {
  label: string; type?: string; value: string;
  onChange: (v: string) => void; placeholder: string;
  icon: React.ElementType; rightElement?: React.ReactNode;
  error?: string; autoFocus?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  return (
    <div>
      <label style={{ fontSize: '0.75rem', fontWeight: '600', color: '#374151', display: 'block', marginBottom: '6px' }}>
        {label}
      </label>
      <div style={{
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
        borderRadius: '10px',
        border: `1.5px solid ${error ? '#EF4444' : focused ? ORANGE : '#E5E7EB'}`,
        backgroundColor: '#fff',
        transition: 'border-color 0.2s',
        boxShadow: focused && !error ? `0 0 0 3px ${ORANGE}18` : 'none',
      }}>
        <Icon size={15} color={error ? '#EF4444' : focused ? ORANGE : '#9CA3AF'}
          style={{ position: 'absolute', left: '12px', flexShrink: 0, transition: 'color 0.2s' }} />
        <input
          type={type}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          autoFocus={autoFocus}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            flex: 1,
            padding: '11px 12px 11px 36px',
            border: 'none',
            outline: 'none',
            backgroundColor: 'transparent',
            fontSize: '0.88rem',
            color: DARK,
            borderRadius: '10px',
          }}
        />
        {rightElement && (
          <div style={{ position: 'absolute', right: '10px' }}>
            {rightElement}
          </div>
        )}
      </div>
      {error && (
        <p style={{ margin: '4px 0 0', fontSize: '0.72rem', color: '#EF4444', display: 'flex', alignItems: 'center', gap: '4px' }}>
          <AlertCircle size={11} /> {error}
        </p>
      )}
    </div>
  );
}

// ── Formulario principal ───────────────────────────────────────────
export default function LoginPage() {
  const { user, loading: authLoading, signIn, signUp, resetPassword } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirectTo = searchParams.get('redirect') || '/admin';

  const [mode,        setMode]        = useState<Mode>('login');
  const [name,        setName]        = useState('');
  const [email,       setEmail]       = useState('');
  const [password,    setPassword]    = useState('');
  const [showPass,    setShowPass]    = useState(false);
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState('');
  const [success,     setSuccess]     = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Si ya está autenticado, redirigir
  useEffect(() => {
    if (!authLoading && user) {
      navigate(redirectTo, { replace: true });
    }
  }, [user, authLoading, navigate, redirectTo]);

  const clearMessages = () => { setError(''); setSuccess(''); setFieldErrors({}); };

  const switchMode = (m: Mode) => {
    clearMessages();
    setMode(m);
    setPassword('');
  };

  // ── Validación básica ──────────────────────────────────────────
  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!email.trim()) errs.email = 'El email es requerido';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errs.email = 'Email inválido';
    if (mode !== 'reset') {
      if (!password) errs.password = 'La contraseña es requerida';
      else if (password.length < 6) errs.password = 'Mínimo 6 caracteres';
    }
    if (mode === 'register' && !name.trim()) errs.name = 'El nombre es requerido';
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // ── Submit ─────────────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();
    if (!validate()) return;

    setLoading(true);
    try {
      if (mode === 'login') {
        const { error } = await signIn(email, password);
        if (error) { setError(error); return; }
        navigate(redirectTo, { replace: true });

      } else if (mode === 'register') {
        const { error } = await signUp(email, password, name);
        if (error) { setError(error); return; }
        navigate(redirectTo, { replace: true });

      } else {
        // reset
        const { error } = await resetPassword(email);
        if (error) { setError(error); return; }
        setSuccess('Te enviamos un enlace de recuperación a tu email. Revisá tu bandeja.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Mostrar spinner si aún se chequea la sesión
  if (authLoading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#F8F9FA' }}>
        <Loader2 size={32} color={ORANGE} style={{ animation: 'spin 1s linear infinite' }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  const titles: Record<Mode, string> = {
    login:    'Bienvenido de vuelta',
    register: 'Crear cuenta',
    reset:    'Recuperar contraseña',
  };
  const subtitles: Record<Mode, string> = {
    login:    'Ingresá a tu panel de administración',
    register: 'Completá los datos para acceder',
    reset:    'Te enviaremos un enlace por email',
  };
  const ctaLabel: Record<Mode, string> = {
    login:    'Ingresar',
    register: 'Crear cuenta',
    reset:    'Enviar enlace',
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      backgroundColor: '#F8F9FA',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif',
    }}>
      {/* ── Panel izquierdo — branding ── */}
      <BrandPanel />

      {/* ── Panel derecho — formulario ── */}
      <div style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px 24px',
        overflowY: 'auto',
      }}>
        <div style={{ width: '100%', maxWidth: '400px' }}>

          {/* Logo móvil (solo visible en pantallas pequeñas, oculto en este mock) */}

          {/* Back button para reset */}
          {mode === 'reset' && (
            <button
              onClick={() => switchMode('login')}
              style={{
                display: 'flex', alignItems: 'center', gap: '6px',
                background: 'none', border: 'none', cursor: 'pointer',
                color: '#6B7280', fontSize: '0.82rem', fontWeight: '600',
                marginBottom: '24px', padding: 0,
              }}
            >
              <ChevronLeft size={16} /> Volver al inicio de sesión
            </button>
          )}

          {/* Encabezado */}
          <div style={{ marginBottom: '28px' }}>
            {/* Tab Login / Registro */}
            {mode !== 'reset' && (
              <div style={{
                display: 'flex',
                backgroundColor: '#F3F4F6',
                borderRadius: '10px',
                padding: '3px',
                marginBottom: '24px',
              }}>
                {(['login', 'register'] as const).map(m => (
                  <button
                    key={m}
                    onClick={() => switchMode(m)}
                    style={{
                      flex: 1,
                      padding: '8px 0',
                      borderRadius: '8px',
                      border: 'none',
                      cursor: 'pointer',
                      fontSize: '0.84rem',
                      fontWeight: '600',
                      transition: 'all 0.2s',
                      backgroundColor: mode === m ? '#fff' : 'transparent',
                      color: mode === m ? DARK : '#6B7280',
                      boxShadow: mode === m ? '0 1px 4px rgba(0,0,0,0.08)' : 'none',
                    }}
                  >
                    {m === 'login' ? 'Iniciar sesión' : 'Crear cuenta'}
                  </button>
                ))}
              </div>
            )}

            <h1 style={{
              margin: '0 0 4px',
              fontSize: '1.45rem',
              fontWeight: '800',
              color: DARK,
              letterSpacing: '-0.01em',
            }}>
              {titles[mode]}
            </h1>
            <p style={{ margin: 0, fontSize: '0.82rem', color: '#6B7280' }}>
              {subtitles[mode]}
            </p>
          </div>

          {/* Formulario */}
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>

            {/* Nombre — solo en registro */}
            {mode === 'register' && (
              <Field
                label="Nombre completo"
                value={name}
                onChange={setName}
                placeholder="Carlos García"
                icon={User}
                error={fieldErrors.name}
                autoFocus
              />
            )}

            {/* Email */}
            <Field
              label="Email"
              type="email"
              value={email}
              onChange={setEmail}
              placeholder="correo@empresa.com"
              icon={Mail}
              error={fieldErrors.email}
              autoFocus={mode !== 'register'}
            />

            {/* Contraseña — no en reset */}
            {mode !== 'reset' && (
              <Field
                label="Contraseña"
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={setPassword}
                placeholder="••••••••"
                icon={Lock}
                error={fieldErrors.password}
                rightElement={
                  <button
                    type="button"
                    onClick={() => setShowPass(p => !p)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, display: 'flex', color: '#9CA3AF' }}
                  >
                    {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                }
              />
            )}

            {/* Olvidé contraseña — solo en login */}
            {mode === 'login' && (
              <div style={{ textAlign: 'right', marginTop: '-6px' }}>
                <button
                  type="button"
                  onClick={() => switchMode('reset')}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    fontSize: '0.75rem', fontWeight: '600', color: ORANGE,
                    padding: 0,
                  }}
                >
                  ¿Olvidaste tu contraseña?
                </button>
              </div>
            )}

            {/* Error general */}
            {error && (
              <div style={{
                display: 'flex', alignItems: 'flex-start', gap: '8px',
                padding: '10px 14px', borderRadius: '9px',
                backgroundColor: '#FEF2F2', border: '1.5px solid #FCA5A5',
              }}>
                <AlertCircle size={15} color="#EF4444" style={{ flexShrink: 0, marginTop: '1px' }} />
                <p style={{ margin: 0, fontSize: '0.8rem', color: '#991B1B', lineHeight: 1.5 }}>{error}</p>
              </div>
            )}

            {/* Success */}
            {success && (
              <div style={{
                display: 'flex', alignItems: 'flex-start', gap: '8px',
                padding: '10px 14px', borderRadius: '9px',
                backgroundColor: '#F0FDF4', border: '1.5px solid #86EFAC',
              }}>
                <CheckCircle2 size={15} color="#22C55E" style={{ flexShrink: 0, marginTop: '1px' }} />
                <p style={{ margin: 0, fontSize: '0.8rem', color: '#166534', lineHeight: 1.5 }}>{success}</p>
              </div>
            )}

            {/* CTA Button */}
            <button
              type="submit"
              disabled={loading}
              style={{
                width: '100%',
                padding: '12px',
                borderRadius: '10px',
                border: 'none',
                backgroundColor: ORANGE,
                color: '#fff',
                fontSize: '0.9rem',
                fontWeight: '700',
                cursor: loading ? 'not-allowed' : 'pointer',
                opacity: loading ? 0.75 : 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '8px',
                transition: 'opacity 0.2s, transform 0.15s',
                marginTop: '4px',
              }}
              onMouseEnter={e => { if (!loading) (e.currentTarget as HTMLElement).style.transform = 'translateY(-1px)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = ''; }}
            >
              {loading ? (
                <>
                  <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} />
                  Procesando...
                </>
              ) : (
                <>
                  {ctaLabel[mode]}
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          {/* Footer */}
          <p style={{ textAlign: 'center', marginTop: '28px', fontSize: '0.72rem', color: '#9CA3AF' }}>
            Al continuar aceptás los{' '}
            <span style={{ color: ORANGE, cursor: 'pointer', fontWeight: '600' }}>Términos de uso</span>
            {' '}y la{' '}
            <span style={{ color: ORANGE, cursor: 'pointer', fontWeight: '600' }}>Política de privacidad</span>.
          </p>
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        * { box-sizing: border-box; }
      `}</style>
    </div>
  );
}
