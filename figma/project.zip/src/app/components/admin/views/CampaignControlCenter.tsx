/* =====================================================
   Campaign Control Center — Charlie v1.5
   Campaign Manager + System Admin · Gateway & Privilege
   ===================================================== */
import React, { useState, useEffect, useCallback } from 'react';
import {
  Settings, Zap, Shield, BarChart2, Plus, Edit2, Archive,
  Play, RefreshCw, ChevronRight, ChevronLeft, AlertTriangle,
  CheckCircle, XCircle, Trash2, Copy, Eye, TrendingUp,
  DollarSign, Layers, Lock, Globe, Calendar, Users,
  ToggleLeft, ToggleRight, Info, Cpu, ChevronDown, ChevronUp,
} from 'lucide-react';
import { OrangeHeader } from '../OrangeHeader';
import type { MainSection } from '../../../AdminDashboard';
import { projectId, publicAnonKey } from '/utils/supabase/info';

// ─── API ───────────────────────────────────────────────────────────────────────
const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-75638143`;
const H = { 'Content-Type': 'application/json', Authorization: `Bearer ${publicAnonKey}` };
async function apiFetch(url: string, opts?: RequestInit): Promise<any> {
  const res = await fetch(url, { headers: H, ...opts });
  if (!res.ok) {
    const text = await res.text().catch(() => res.statusText);
    throw new Error(`HTTP ${res.status}: ${text}`);
  }
  return res.json();
}

const api = {
  list:     ()                => apiFetch(`${BASE}/campaigns`),
  get:      (id:string)       => apiFetch(`${BASE}/campaigns/${id}`),
  create:   (b:any)           => apiFetch(`${BASE}/campaigns`,                    { method:'POST',  body:JSON.stringify(b) }),
  update:   (id:string, b:any)=> apiFetch(`${BASE}/campaigns/${id}`,              { method:'PATCH', body:JSON.stringify(b) }),
  activate: (id:string, ov=false) => apiFetch(`${BASE}/campaigns/${id}/activate`, { method:'POST',  body:JSON.stringify({override:ov}) }),
  archive:  (id:string)       => apiFetch(`${BASE}/campaigns/${id}/archive`,      { method:'POST'  }),
  validate: (id:string)       => apiFetch(`${BASE}/campaigns/${id}/validate`,     { method:'POST'  }),
  simulate: (id:string, expected_spins:number) => apiFetch(`${BASE}/campaigns/${id}/simulate`, { method:'POST', body:JSON.stringify({expected_spins}) }),
};

// ─── Types ─────────────────────────────────────────────────────────────────────
export type CampaignType   = 'gateway' | 'privilege';
export type CampaignStatus = 'draft' | 'scheduled' | 'active' | 'archived';
export type FreqType       = 'monthly' | 'weekly' | 'custom';
export type TierType       = 'standard' | 'premium' | 'special';
export type ThemeId        = 'dark_gold' | 'dark_silver' | 'midnight_blue' | 'limited_edition';

export interface Reward {
  reward_id:             string;
  name:                  string;
  description:           string;
  icon:                  string;
  tier:                  TierType;
  probability_weight:    number;
  stock_limit:           number;
  stock_remaining?:      number;
  cost_estimate:         number;
  associated_category:   string;
  requires_manual_review:boolean;
}

export interface EligibilityRules {
  logic:                          'AND' | 'OR';
  minimum_monthly_spend:          number;
  monthly_spend_multiplier:       number;
  minimum_category_diversity:     number;
  activation_conversion_required: boolean;
  user_score_threshold:           number;
  purchase_count_threshold:       number;
  custom_behavior_flag:           string | null;
}

export interface Economic {
  budget_limit:               number;
  projected_cost:             number;
  expected_redemption_rate:   number;
  deviation_alert_threshold:  number;
  auto_stop_enabled:          boolean;
}

export interface Campaign {
  id:                   string;
  name:                 string;
  campaign_type:        CampaignType;
  status:               CampaignStatus;
  start_date:           string | null;
  end_date:             string | null;
  next_activation_date: string | null;
  frequency:            FreqType;
  max_spins_per_user:   number;
  visibility:           'public' | 'hidden_unlock';
  version:              number;
  theme_id:             ThemeId;
  rewards:              Reward[];
  eligibility_rules:    EligibilityRules | null;
  economic:             Economic;
  created_at:           string;
  updated_at:           string;
  created_by:           string;
  audit_log:            { action:string; at:string; by:string; note:string }[];
}

// ─── Constants & helpers ───────────────────────────────────────────────────────
const O = '#FF6835';
const GOLD = '#B89B55';

const THEMES: Record<ThemeId, { name:string; bg:string; accent:string }> = {
  dark_gold:       { name:'Dark Gold',       bg:'#070708', accent:'#B89B55' },
  dark_silver:     { name:'Dark Silver',     bg:'#080809', accent:'#A0A0A0' },
  midnight_blue:   { name:'Midnight Blue',   bg:'#06080F', accent:'#4A6FA5' },
  limited_edition: { name:'Limited Edition', bg:'#0A0705', accent:'#C98D45' },
};

const STATUS_CFG: Record<CampaignStatus, { label:string; bg:string; color:string; Icon:any }> = {
  draft:     { label:'Borrador',    bg:'#F3F4F6', color:'#6B7280', Icon: Edit2       },
  scheduled: { label:'Programada', bg:'#EFF6FF', color:'#2563EB', Icon: Calendar    },
  active:    { label:'Activa',     bg:'#DCFCE7', color:'#16A34A', Icon: Play        },
  archived:  { label:'Archivada',  bg:'#F3F4F6', color:'#374151', Icon: Archive     },
};

const TYPE_CFG: Record<CampaignType, { label:string; color:string; bg:string; Icon:any }> = {
  gateway:   { label:'Gateway',   color:'#FF6835', bg:'rgba(255,104,53,0.10)',  Icon: Globe  },
  privilege: { label:'Privilege', color:'#B89B55', bg:'rgba(184,155,85,0.10)', Icon: Lock   },
};

const TIER_CFG: Record<TierType, { color:string }> = {
  standard: { color:'#6B7280' },
  premium:  { color:'#B89B55' },
  special:  { color:'#C98D45' },
};

function emptyReward(): Reward {
  return {
    reward_id: '',
    name: '',
    description: '',
    icon: '◆',
    tier: 'standard',
    probability_weight: 12,
    stock_limit: 0,
    cost_estimate: 0,
    associated_category: 'general',
    requires_manual_review: false,
  };
}

function emptyEligibility(): EligibilityRules {
  return {
    logic: 'AND',
    minimum_monthly_spend: 0,
    monthly_spend_multiplier: 1,
    minimum_category_diversity: 0,
    activation_conversion_required: false,
    user_score_threshold: 0,
    purchase_count_threshold: 0,
    custom_behavior_flag: null,
  };
}

function emptyEconomic(): Economic {
  return {
    budget_limit: 5000,
    projected_cost: 0,
    expected_redemption_rate: 0.75,
    deviation_alert_threshold: 20,
    auto_stop_enabled: true,
  };
}

function emptyCampaign(type: CampaignType = 'gateway'): Partial<Campaign> {
  return {
    name: '',
    campaign_type: type,
    status: 'draft',
    start_date: null,
    end_date: null,
    next_activation_date: null,
    frequency: 'monthly',
    max_spins_per_user: 1,
    visibility: 'public',
    theme_id: 'dark_gold',
    rewards: [],
    eligibility_rules: type === 'privilege' ? emptyEligibility() : null,
    economic: emptyEconomic(),
  };
}

// ─── Sub-components ────────────────────────────────────────────────────────────
function StatusPill({ status }: { status: CampaignStatus }) {
  const cfg = STATUS_CFG[status];
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:'4px', padding:'3px 10px', borderRadius:'20px', background:cfg.bg, color:cfg.color, fontSize:'0.7rem', fontWeight:700 }}>
      <cfg.Icon size={10} /> {cfg.label}
    </span>
  );
}

function TypePill({ type }: { type: CampaignType }) {
  const cfg = TYPE_CFG[type];
  return (
    <span style={{ display:'inline-flex', alignItems:'center', gap:'4px', padding:'3px 10px', borderRadius:'20px', background:cfg.bg, color:cfg.color, fontSize:'0.7rem', fontWeight:700 }}>
      <cfg.Icon size={10} /> {cfg.label}
    </span>
  );
}

function BudgetBar({ used, limit }: { used:number; limit:number }) {
  const pct = limit > 0 ? Math.min((used/limit)*100, 100) : 0;
  const color = pct > 90 ? '#DC2626' : pct > 70 ? '#D97706' : '#16A34A';
  return (
    <div style={{ width:'100%' }}>
      <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.65rem', color:'#6B7280', marginBottom:'3px' }}>
        <span>${used.toFixed(0)} / ${limit.toFixed(0)}</span>
        <span style={{ color }}>{pct.toFixed(0)}%</span>
      </div>
      <div style={{ height:'4px', background:'#F3F4F6', borderRadius:'2px', overflow:'hidden' }}>
        <div style={{ width:`${pct}%`, height:'100%', background:color, borderRadius:'2px', transition:'width 0.4s' }} />
      </div>
    </div>
  );
}

// ─── Builder Steps ─────────────────────────────────────────────────────────────
const STEPS = ['Configuración', 'Rewards', 'Elegibilidad', 'Tema', 'Economía', 'Revisión'];
const STEP_ICONS = [Settings, Layers, Lock, Cpu, DollarSign, CheckCircle];

// ─── Main Component ────────────────────────────────────────────────────────────
interface Props { onNavigate: (s: MainSection) => void; }

export function CampaignControlCenter({ onNavigate }: Props) {
  const [tab,          setTab]          = useState<'campaigns'|'builder'|'system'>('campaigns');
  const [campaigns,    setCampaigns]    = useState<Campaign[]>([]);
  const [loading,      setLoading]      = useState(true);
  const [error,        setError]        = useState<string|null>(null);

  // Builder state
  const [builderData,  setBuilderData]  = useState<Partial<Campaign>>(emptyCampaign('gateway'));
  const [step,         setStep]         = useState(0);
  const [editingId,    setEditingId]    = useState<string|null>(null);
  const [saving,       setSaving]       = useState(false);

  // Validation / simulate state
  const [validResult,  setValidResult]  = useState<any>(null);
  const [simResult,    setSimResult]    = useState<any>(null);
  const [simSpins,     setSimSpins]     = useState(1000);
  const [activating,   setActivating]   = useState<string|null>(null);

  // System admin state
  const [sysTab,       setSysTab]       = useState<'thresholds'|'themes'|'audit'>('thresholds');

  // ── Load ────────────────────────────────────────────────────────────────────
  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const data = await api.list();
      if (Array.isArray(data)) {
        setCampaigns(data);
      } else {
        setError('Respuesta inesperada del servidor: ' + JSON.stringify(data));
      }
    } catch(e:any) {
      const msg: string = e?.message ?? String(e);
      setError('Error de conexión con el servidor: ' + msg);
      console.error('CampaignControlCenter load error:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // ── Builder helpers ─────────────────────────────────────────────────────────
  const openCreate = (type: CampaignType) => {
    setBuilderData(emptyCampaign(type));
    setEditingId(null);
    setStep(0);
    setValidResult(null);
    setSimResult(null);
    setTab('builder');
  };

  const openEdit = async (camp: Campaign) => {
    setBuilderData({ ...camp });
    setEditingId(camp.id);
    setStep(0);
    setValidResult(null);
    setSimResult(null);
    setTab('builder');
  };

  const saveBuilder = async () => {
    setSaving(true);
    try {
      let result: Campaign;
      if (editingId) {
        result = await api.update(editingId, builderData);
      } else {
        result = await api.create(builderData);
      }
      if (result.id) {
        await load();
        setTab('campaigns');
      } else {
        setError('Error al guardar: ' + JSON.stringify(result));
      }
    } catch(e:any) {
      setError('Error al guardar: ' + e.message);
      console.error('saveBuilder error:', e);
    } finally {
      setSaving(false);
    }
  };

  const runValidate = async () => {
    if (!editingId) return;
    const r = await api.validate(editingId);
    setValidResult(r);
  };

  const runSimulate = async () => {
    if (!editingId) return;
    const r = await api.simulate(editingId, simSpins);
    setSimResult(r);
  };

  const doActivate = async (id: string, override = false) => {
    setActivating(id);
    try {
      const r = await api.activate(id, override);
      if (r.status === 'active') {
        await load();
      } else if (r.requires_override) {
        if (window.confirm(`⚠️ ${r.error}\n\nSolo un System Admin puede aprobar este override. ¿Continuar de todos modos?`)) {
          await doActivate(id, true);
        }
      } else {
        alert('Error: ' + (r.error ?? JSON.stringify(r)));
      }
    } catch(e:any) {
      alert('Error de activación: ' + e.message);
    } finally {
      setActivating(null);
    }
  };

  const doArchive = async (id: string) => {
    if (!confirm('¿Archivar esta campaña?')) return;
    await api.archive(id);
    await load();
  };

  // ── Reward helpers ──────────────────────────────────────────────────────────
  const addReward = () => {
    setBuilderData(prev => ({
      ...prev,
      rewards: [...(prev.rewards ?? []), emptyReward()],
    }));
  };
  const updateReward = (idx: number, field: keyof Reward, value: any) => {
    setBuilderData(prev => {
      const rewards = [...(prev.rewards ?? [])];
      rewards[idx] = { ...rewards[idx], [field]: value };
      return { ...prev, rewards };
    });
  };
  const removeReward = (idx: number) => {
    setBuilderData(prev => ({
      ...prev,
      rewards: (prev.rewards ?? []).filter((_, i) => i !== idx),
    }));
  };

  const totalWeight = (builderData.rewards ?? []).reduce((s, r) => s + (r.probability_weight ?? 0), 0);

  // ─── RENDER ─────────────────────────────────────────────────────────────────
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <OrangeHeader
        icon={Zap}
        title="Campaign Control Center"
        subtitle="Gestión de campañas Gateway y Privilege · Activation Engine · Economic Safeguards"
        actions={[
          { label:'↺ Recargar', onClick: load },
          { label:'Volver', onClick: () => onNavigate('marketing') },
        ]}
      />

      {/* ── Tab Bar ── */}
      <div style={{ background:'#fff', borderBottom:'1px solid #E5E7EB', flexShrink:0 }}>
        <div style={{ display:'flex', padding:'0 28px', gap:'0' }}>
          {(['campaigns','builder','system'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              style={{ padding:'13px 20px', border:'none', background:'transparent', cursor:'pointer',
                color: tab===t ? O : '#6B7280', fontWeight: tab===t ? 700 : 500, fontSize:'0.875rem',
                borderBottom: tab===t ? `2px solid ${O}` : '2px solid transparent' }}>
              { t==='campaigns' ? '🎛 Campañas' : t==='builder' ? '🏗 Builder' : '⚙️ Sistema' }
            </button>
          ))}
        </div>
      </div>

      <div style={{ flex:1, overflowY:'auto', background:'#F8F9FA' }}>

        {/* ═══════════════════════════════ CAMPAIGNS TAB ══════════════════ */}
        {tab === 'campaigns' && (
          <div style={{ padding:'24px 28px' }}>

            {/* Header row */}
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px' }}>
              <div>
                <h2 style={{ margin:0, fontWeight:800, color:'#111827', fontSize:'1.1rem' }}>Campañas</h2>
                <p style={{ margin:'2px 0 0', color:'#6B7280', fontSize:'0.78rem' }}>
                  {campaigns.filter(c=>c.status==='active').length} activas · {campaigns.length} total
                </p>
              </div>
              <div style={{ display:'flex', gap:'8px' }}>
                <button onClick={() => openCreate('gateway')}
                  style={{ display:'flex', alignItems:'center', gap:'6px', padding:'9px 16px', background:O, color:'#fff', border:'none', borderRadius:'8px', fontWeight:700, cursor:'pointer', fontSize:'0.82rem' }}>
                  <Plus size={14}/> Nueva Gateway
                </button>
                <button onClick={() => openCreate('privilege')}
                  style={{ display:'flex', alignItems:'center', gap:'6px', padding:'9px 16px', background:'transparent', color:GOLD, border:`1px solid ${GOLD}`, borderRadius:'8px', fontWeight:700, cursor:'pointer', fontSize:'0.82rem' }}>
                  <Lock size={14}/> Nueva Privilege
                </button>
              </div>
            </div>

            {error && (
              <div style={{ background:'#FEF2F2', border:'1px solid #FECACA', borderRadius:'8px', padding:'12px 16px', color:'#DC2626', fontSize:'0.82rem', marginBottom:'16px', display:'flex', alignItems:'center', gap:'8px' }}>
                <AlertTriangle size={15}/> {error}
              </div>
            )}

            {/* KPI row */}
            <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'14px', marginBottom:'24px' }}>
              {[
                { label:'Total campañas', value: campaigns.length,                                    color:O,       Icon: Layers    },
                { label:'Activas ahora',  value: campaigns.filter(c=>c.status==='active').length,     color:'#16A34A', Icon: Play    },
                { label:'Borradores',     value: campaigns.filter(c=>c.status==='draft').length,      color:'#6B7280', Icon: Edit2   },
                { label:'Archivadas',     value: campaigns.filter(c=>c.status==='archived').length,   color:'#374151', Icon: Archive },
              ].map((k,i) => (
                <div key={i} style={{ background:'#fff', border:`1px solid ${k.color}22`, borderRadius:'10px', padding:'16px 18px', display:'flex', alignItems:'center', gap:'12px' }}>
                  <div style={{ width:'36px', height:'36px', borderRadius:'8px', background:k.color+'18', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                    <k.Icon size={17} color={k.color}/>
                  </div>
                  <div>
                    <p style={{ margin:0, fontSize:'0.72rem', color:'#6B7280' }}>{k.label}</p>
                    <p style={{ margin:0, fontSize:'1.5rem', fontWeight:900, color:k.color }}>{k.value}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Campaign table */}
            {loading ? (
              <div style={{ textAlign:'center', padding:'48px', color:'#9CA3AF', fontSize:'0.82rem' }}>
                <RefreshCw size={20} style={{ display:'block', margin:'0 auto 8px', opacity:0.5 }}/>
                Cargando campañas...
              </div>
            ) : campaigns.length === 0 ? (
              <div style={{ background:'#fff', border:'1px solid #E5E7EB', borderRadius:'12px', padding:'60px', textAlign:'center' }}>
                <Zap size={40} style={{ color:'#E5E7EB', display:'block', margin:'0 auto 16px' }}/>
                <h3 style={{ margin:'0 0 8px', fontWeight:800, color:'#111827' }}>Sin campañas</h3>
                <p style={{ margin:'0 0 20px', color:'#6B7280', fontSize:'0.82rem' }}>Creá tu primera campaña Gateway o Privilege</p>
                <div style={{ display:'flex', gap:'8px', justifyContent:'center' }}>
                  <button onClick={() => openCreate('gateway')} style={{ padding:'9px 18px', background:O, color:'#fff', border:'none', borderRadius:'8px', fontWeight:700, cursor:'pointer', fontSize:'0.82rem' }}>
                    + Gateway
                  </button>
                  <button onClick={() => openCreate('privilege')} style={{ padding:'9px 18px', background:GOLD, color:'#fff', border:'none', borderRadius:'8px', fontWeight:700, cursor:'pointer', fontSize:'0.82rem' }}>
                    + Privilege
                  </button>
                </div>
              </div>
            ) : (
              <div style={{ background:'#fff', border:'1px solid #E5E7EB', borderRadius:'12px', overflow:'hidden' }}>
                <table style={{ width:'100%', borderCollapse:'collapse' }}>
                  <thead>
                    <tr style={{ background:'#F9FAFB' }}>
                      {['Campaña','Tipo','Estado','Rewards','Presupuesto','Versión','Fechas','Acciones'].map(h => (
                        <th key={h} style={{ padding:'11px 14px', textAlign:'left', fontSize:'0.7rem', fontWeight:700, color:'#374151', textTransform:'uppercase', letterSpacing:'0.04em', whiteSpace:'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {campaigns.map((c, i) => (
                      <tr key={c.id} style={{ borderTop:'1px solid #F3F4F6', background: i%2===0 ? '#fff' : '#FAFAFA' }}>
                        <td style={{ padding:'12px 14px' }}>
                          <div style={{ fontWeight:700, color:'#111827', fontSize:'0.85rem' }}>{c.name}</div>
                          <div style={{ fontSize:'0.68rem', color:'#9CA3AF', marginTop:'2px', fontFamily:'monospace' }}>{c.id}</div>
                        </td>
                        <td style={{ padding:'12px 14px' }}><TypePill type={c.campaign_type}/></td>
                        <td style={{ padding:'12px 14px' }}><StatusPill status={c.status}/></td>
                        <td style={{ padding:'12px 14px', color:'#374151', fontSize:'0.82rem', fontWeight:600 }}>
                          {c.rewards?.length ?? 0}
                          <span style={{ color:'#9CA3AF', fontWeight:400 }}> seg.</span>
                        </td>
                        <td style={{ padding:'12px 14px', minWidth:'120px' }}>
                          <BudgetBar used={c.economic?.projected_cost??0} limit={c.economic?.budget_limit??5000}/>
                        </td>
                        <td style={{ padding:'12px 14px', color:'#6B7280', fontSize:'0.78rem', fontFamily:'monospace' }}>v{c.version}</td>
                        <td style={{ padding:'12px 14px', color:'#6B7280', fontSize:'0.72rem' }}>
                          {c.start_date ? <div>{c.start_date}</div> : <span style={{color:'#D1D5DB'}}>–</span>}
                          {c.end_date   ? <div>{c.end_date}</div>   : null}
                        </td>
                        <td style={{ padding:'12px 14px' }}>
                          <div style={{ display:'flex', gap:'5px', alignItems:'center' }}>
                            <button onClick={() => openEdit(c)} title="Editar"
                              style={{ padding:'5px 8px', background:'#F3F4F6', border:'none', borderRadius:'6px', cursor:'pointer', color:'#374151', display:'flex', alignItems:'center', gap:'3px', fontSize:'0.72rem', fontWeight:600 }}>
                              <Edit2 size={11}/> Editar
                            </button>
                            {c.status !== 'active' && c.status !== 'archived' && (
                              <button onClick={() => doActivate(c.id)} disabled={activating===c.id}
                                style={{ padding:'5px 8px', background:'#DCFCE7', border:'none', borderRadius:'6px', cursor:'pointer', color:'#16A34A', display:'flex', alignItems:'center', gap:'3px', fontSize:'0.72rem', fontWeight:700 }}>
                                {activating===c.id ? '...' : <><Play size={11}/> Activar</>}
                              </button>
                            )}
                            {c.status === 'active' && (
                              <button onClick={() => doArchive(c.id)}
                                style={{ padding:'5px 8px', background:'#FEF3C7', border:'none', borderRadius:'6px', cursor:'pointer', color:'#D97706', display:'flex', alignItems:'center', gap:'3px', fontSize:'0.72rem', fontWeight:700 }}>
                                <Archive size={11}/> Archivar
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ═══════════════════════════════ BUILDER TAB ════════════════════ */}
        {tab === 'builder' && (
          <div style={{ padding:'24px 28px', display:'grid', gridTemplateColumns:'200px 1fr', gap:'24px', alignItems:'start' }}>

            {/* Stepper sidebar */}
            <div style={{ position:'sticky', top:'24px' }}>
              {STEPS.map((s, i) => {
                const Icon = STEP_ICONS[i];
                const active = step === i;
                const done   = step > i;
                // Hide Eligibility for gateway
                if (i === 2 && builderData.campaign_type === 'gateway') return null;
                return (
                  <button key={i} onClick={() => setStep(i)}
                    style={{ width:'100%', display:'flex', alignItems:'center', gap:'10px', padding:'10px 12px', marginBottom:'4px',
                      background: active ? O+'18' : 'transparent', border: active ? `1px solid ${O}44` : '1px solid transparent',
                      borderRadius:'8px', cursor:'pointer', textAlign:'left' }}>
                    <div style={{ width:'28px', height:'28px', borderRadius:'50%', background: active ? O : done ? '#DCFCE7' : '#F3F4F6',
                      display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
                      {done ? <CheckCircle size={14} color="#16A34A"/> : <Icon size={13} color={active ? '#fff' : '#6B7280'}/>}
                    </div>
                    <span style={{ fontSize:'0.78rem', fontWeight: active ? 700 : 500, color: active ? O : '#374151' }}>{s}</span>
                  </button>
                );
              })}
              <div style={{ marginTop:'12px', padding:'10px 12px', background:'#F9FAFB', borderRadius:'8px', fontSize:'0.68rem', color:'#9CA3AF', lineHeight:1.5 }}>
                {editingId ? `Editando v${builderData.version ?? 1}` : 'Nueva campaña'}
                <br/>
                {builderData.name || '–'}
              </div>
            </div>

            {/* Step content */}
            <div style={{ background:'#fff', border:'1px solid #E5E7EB', borderRadius:'12px', padding:'28px 32px' }}>

              {/* ── Step 0: Configuración ── */}
              {step === 0 && (
                <BuilderStep title="Configuración de Campaña" icon={Settings}>
                  <FieldRow label="Nombre de la campaña" required>
                    <input value={builderData.name ?? ''} onChange={e => setBuilderData(p=>({...p,name:e.target.value}))}
                      placeholder="ej: Privilegio Marzo 2026"
                      style={inputStyle}/>
                  </FieldRow>
                  <FieldRow label="Tipo de campaña">
                    <div style={{ display:'flex', gap:'8px' }}>
                      {(['gateway','privilege'] as CampaignType[]).map(t => {
                        const cfg = TYPE_CFG[t];
                        const sel = builderData.campaign_type === t;
                        return (
                          <button key={t} onClick={() => setBuilderData(p => ({
                            ...p, campaign_type: t,
                            eligibility_rules: t === 'privilege' ? emptyEligibility() : null
                          }))}
                            style={{ flex:1, padding:'12px', border:`2px solid ${sel ? cfg.color : '#E5E7EB'}`,
                              borderRadius:'8px', background: sel ? cfg.bg : '#fff', cursor:'pointer', textAlign:'left' }}>
                            <div style={{ display:'flex', alignItems:'center', gap:'6px', marginBottom:'4px' }}>
                              <cfg.Icon size={14} color={sel ? cfg.color : '#9CA3AF'}/>
                              <span style={{ fontWeight:700, color: sel ? cfg.color : '#374151', fontSize:'0.82rem' }}>{cfg.label}</span>
                            </div>
                            <p style={{ margin:0, fontSize:'0.7rem', color:'#6B7280' }}>
                              {t==='gateway' ? 'Pública — accesible por todos los usuarios' : 'Privada — acceso por comportamiento del usuario'}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                  </FieldRow>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px' }}>
                    <FieldRow label="Fecha de inicio">
                      <input type="date" value={builderData.start_date ?? ''} onChange={e => setBuilderData(p=>({...p,start_date:e.target.value||null}))} style={inputStyle}/>
                    </FieldRow>
                    <FieldRow label="Fecha de fin">
                      <input type="date" value={builderData.end_date ?? ''} onChange={e => setBuilderData(p=>({...p,end_date:e.target.value||null}))} style={inputStyle}/>
                    </FieldRow>
                  </div>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px' }}>
                    <FieldRow label="Frecuencia">
                      <select value={builderData.frequency ?? 'monthly'} onChange={e => setBuilderData(p=>({...p,frequency:e.target.value as FreqType}))} style={inputStyle}>
                        <option value="monthly">Mensual</option>
                        <option value="weekly">Semanal</option>
                        <option value="custom">Personalizada</option>
                      </select>
                    </FieldRow>
                    <FieldRow label="Max spins por usuario">
                      <input type="number" min={1} value={builderData.max_spins_per_user ?? 1}
                        onChange={e => setBuilderData(p=>({...p,max_spins_per_user:+e.target.value}))} style={inputStyle}/>
                    </FieldRow>
                  </div>
                  <FieldRow label="Visibilidad">
                    <div style={{ display:'flex', gap:'8px' }}>
                      {(['public','hidden_unlock'] as const).map(v => (
                        <button key={v} onClick={() => setBuilderData(p=>({...p,visibility:v}))}
                          style={{ flex:1, padding:'9px', border:`2px solid ${builderData.visibility===v ? O : '#E5E7EB'}`,
                            borderRadius:'7px', background: builderData.visibility===v ? O+'10' : '#fff', cursor:'pointer', fontSize:'0.78rem', fontWeight: builderData.visibility===v ? 700 : 400, color: builderData.visibility===v ? O : '#374151' }}>
                          {v === 'public' ? '🌐 Pública' : '🔒 Desbloqueo oculto'}
                        </button>
                      ))}
                    </div>
                  </FieldRow>
                </BuilderStep>
              )}

              {/* ── Step 1: Rewards ── */}
              {step === 1 && (
                <BuilderStep title="Reward Pool" icon={Layers}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'16px' }}>
                    <div>
                      <span style={{ fontSize:'0.78rem', color:'#6B7280' }}>
                        {(builderData.rewards??[]).length} rewards · Peso total: &nbsp;
                        <span style={{ fontWeight:700, color: Math.abs(totalWeight-100) <= 1 ? '#16A34A' : '#D97706' }}>
                          {totalWeight}%
                        </span>
                        {Math.abs(totalWeight-100) > 1 && <span style={{ color:'#D97706' }}> (recomendado 100%)</span>}
                      </span>
                    </div>
                    <button onClick={addReward}
                      style={{ display:'flex', alignItems:'center', gap:'5px', padding:'7px 14px', background:O, color:'#fff', border:'none', borderRadius:'7px', cursor:'pointer', fontSize:'0.78rem', fontWeight:700 }}>
                      <Plus size={13}/> Agregar reward
                    </button>
                  </div>

                  {(builderData.rewards??[]).length === 0 && (
                    <div style={{ padding:'40px', textAlign:'center', color:'#9CA3AF', fontSize:'0.82rem', border:'2px dashed #E5E7EB', borderRadius:'10px' }}>
                      Sin rewards. Agregá al menos uno para poder activar.
                    </div>
                  )}

                  <div style={{ display:'flex', flexDirection:'column', gap:'8px' }}>
                    {(builderData.rewards??[]).map((r, idx) => (
                      <RewardRow key={idx} reward={r} idx={idx} onUpdate={updateReward} onRemove={removeReward}/>
                    ))}
                  </div>
                </BuilderStep>
              )}

              {/* ── Step 2: Elegibilidad (privilege only) ── */}
              {step === 2 && builderData.campaign_type === 'privilege' && (
                <BuilderStep title="Reglas de Elegibilidad" icon={Lock}>
                  <div style={{ background:'#F0FDF4', border:'1px solid #BBF7D0', borderRadius:'8px', padding:'12px 16px', marginBottom:'20px', fontSize:'0.78rem', color:'#15803D' }}>
                    Estas reglas determinan si un usuario puede activar la rueda Privilege. Solo se aplican a campañas de tipo Privilege.
                  </div>
                  {builderData.eligibility_rules && (
                    <EligibilityEditor
                      rules={builderData.eligibility_rules}
                      onChange={r => setBuilderData(p=>({...p, eligibility_rules:r}))}
                    />
                  )}
                </BuilderStep>
              )}

              {/* ── Step 3: Tema ── */}
              {step === (builderData.campaign_type === 'privilege' ? 3 : 2) && (
                <BuilderStep title="Sistema de Temas" icon={Cpu}>
                  <p style={{ color:'#6B7280', fontSize:'0.8rem', marginBottom:'16px' }}>
                    Temas predefinidos controlados. No se permiten colores arbitrarios. Gateway admite variantes más dinámicas.
                  </p>
                  <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:'12px' }}>
                    {(Object.entries(THEMES) as [ThemeId, typeof THEMES[ThemeId]][]).map(([id, theme]) => {
                      const selected = builderData.theme_id === id;
                      const allowed  = builderData.campaign_type === 'gateway' || id === 'dark_gold' || id === 'dark_silver' || id === 'limited_edition';
                      return (
                        <button key={id} disabled={!allowed} onClick={() => setBuilderData(p=>({...p,theme_id:id}))}
                          style={{ padding:'16px', border:`2px solid ${selected ? theme.accent : '#E5E7EB'}`, borderRadius:'10px',
                            background: selected ? theme.bg : '#fff', cursor: allowed ? 'pointer' : 'not-allowed',
                            textAlign:'left', opacity: allowed ? 1 : 0.4, transition:'all 0.15s' }}>
                          <div style={{ width:'100%', height:'36px', borderRadius:'6px', background:theme.bg, border:'1px solid rgba(255,255,255,0.08)', marginBottom:'10px', position:'relative' }}>
                            <div style={{ position:'absolute', bottom:'6px', left:'6px', right:'6px', height:'3px', borderRadius:'2px', background:theme.accent }}/>
                          </div>
                          <div style={{ fontWeight:700, color: selected ? theme.accent : '#374151', fontSize:'0.82rem' }}>{theme.name}</div>
                          <div style={{ fontSize:'0.68rem', color:'#9CA3AF', marginTop:'2px' }}>Acento: {theme.accent}</div>
                          {!allowed && <div style={{ fontSize:'0.65rem', color:'#D97706', marginTop:'3px' }}>Solo campañas Gateway</div>}
                        </button>
                      );
                    })}
                  </div>
                </BuilderStep>
              )}

              {/* ── Step 4: Economía ── */}
              {step === (builderData.campaign_type === 'privilege' ? 4 : 3) && (
                <BuilderStep title="Controles Económicos" icon={DollarSign}>
                  <EconomicEditor
                    economic={builderData.economic ?? emptyEconomic()}
                    rewards={builderData.rewards ?? []}
                    onChange={e => setBuilderData(p=>({...p,economic:e}))}
                  />
                </BuilderStep>
              )}

              {/* ── Step 5: Revisión ── */}
              {step === (builderData.campaign_type === 'privilege' ? 5 : 4) && (
                <BuilderStep title="Revisión y Guardar" icon={CheckCircle}>
                  <CampaignSummary campaign={builderData}/>

                  {/* Validate */}
                  {editingId && (
                    <div style={{ marginTop:'24px', padding:'18px', background:'#F9FAFB', borderRadius:'10px', border:'1px solid #E5E7EB' }}>
                      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'12px' }}>
                        <span style={{ fontWeight:700, color:'#111827', fontSize:'0.88rem' }}>Validación antes de activar</span>
                        <button onClick={runValidate}
                          style={{ padding:'7px 14px', background:O, color:'#fff', border:'none', borderRadius:'7px', cursor:'pointer', fontSize:'0.78rem', fontWeight:700 }}>
                          Validar
                        </button>
                      </div>
                      {validResult && <ValidationResult result={validResult}/>}
                    </div>
                  )}

                  {/* Simulate */}
                  {editingId && (
                    <div style={{ marginTop:'16px', padding:'18px', background:'#F9FAFB', borderRadius:'10px', border:'1px solid #E5E7EB' }}>
                      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'12px' }}>
                        <div>
                          <span style={{ fontWeight:700, color:'#111827', fontSize:'0.88rem' }}>Simulación de impacto económico</span>
                          <div style={{ display:'flex', alignItems:'center', gap:'8px', marginTop:'6px' }}>
                            <input type="number" value={simSpins} onChange={e=>setSimSpins(+e.target.value)} min={100}
                              style={{ ...inputStyle, width:'100px' }}/>
                            <span style={{ fontSize:'0.75rem', color:'#6B7280' }}>spins esperados</span>
                          </div>
                        </div>
                        <button onClick={runSimulate}
                          style={{ padding:'7px 14px', background:'#1D4ED8', color:'#fff', border:'none', borderRadius:'7px', cursor:'pointer', fontSize:'0.78rem', fontWeight:700 }}>
                          Simular
                        </button>
                      </div>
                      {simResult && <SimulationResult result={simResult}/>}
                    </div>
                  )}
                </BuilderStep>
              )}

              {/* Navigation */}
              <div style={{ display:'flex', justifyContent:'space-between', marginTop:'28px', paddingTop:'20px', borderTop:'1px solid #F3F4F6' }}>
                <button disabled={step===0} onClick={() => setStep(s=>s-1)}
                  style={{ display:'flex', alignItems:'center', gap:'5px', padding:'9px 16px', background:'#F3F4F6', border:'none', borderRadius:'8px', cursor:step===0?'not-allowed':'pointer', color:'#374151', fontWeight:600, fontSize:'0.82rem', opacity:step===0?0.4:1 }}>
                  <ChevronLeft size={14}/> Anterior
                </button>
                <div style={{ display:'flex', gap:'8px' }}>
                  <button onClick={() => setTab('campaigns')}
                    style={{ padding:'9px 16px', background:'transparent', border:'1px solid #E5E7EB', borderRadius:'8px', cursor:'pointer', color:'#6B7280', fontWeight:600, fontSize:'0.82rem' }}>
                    Cancelar
                  </button>
                  <button onClick={saveBuilder} disabled={saving || !builderData.name}
                    style={{ display:'flex', alignItems:'center', gap:'5px', padding:'9px 18px', background: saving || !builderData.name ? '#E5E7EB' : O,
                      border:'none', borderRadius:'8px', cursor: saving || !builderData.name ? 'not-allowed' : 'pointer',
                      color: saving || !builderData.name ? '#9CA3AF' : '#fff', fontWeight:700, fontSize:'0.82rem' }}>
                    {saving ? '...' : editingId ? '💾 Guardar cambios' : '✚ Crear campaña'}
                  </button>
                  {step < (builderData.campaign_type==='privilege'?5:4) && (
                    <button onClick={() => setStep(s=>s+1)}
                      style={{ display:'flex', alignItems:'center', gap:'5px', padding:'9px 16px', background:'#111827', border:'none', borderRadius:'8px', cursor:'pointer', color:'#fff', fontWeight:600, fontSize:'0.82rem' }}>
                      Siguiente <ChevronRight size={14}/>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ═══════════════════════════════ SYSTEM TAB ═════════════════════ */}
        {tab === 'system' && (
          <div style={{ padding:'24px 28px' }}>
            <div style={{ background:'linear-gradient(135deg,#111827,#1F2937)', borderRadius:'12px', padding:'20px 24px', marginBottom:'24px', display:'flex', alignItems:'center', gap:'14px' }}>
              <Shield size={24} color={GOLD}/>
              <div>
                <h3 style={{ margin:0, color:'#fff', fontWeight:800 }}>System Admin Level</h3>
                <p style={{ margin:'3px 0 0', color:'rgba(255,255,255,0.5)', fontSize:'0.78rem' }}>
                  Configuración estratégica · Audit log · Thresholds globales · Catálogo de temas
                </p>
              </div>
              <div style={{ marginLeft:'auto', padding:'5px 12px', background:'rgba(184,155,85,0.15)', border:'1px solid rgba(184,155,85,0.3)', borderRadius:'20px', color:GOLD, fontSize:'0.7rem', fontWeight:700 }}>
                SYSTEM ADMIN
              </div>
            </div>

            <div style={{ display:'flex', gap:'0', marginBottom:'20px', background:'#fff', border:'1px solid #E5E7EB', borderRadius:'8px', overflow:'hidden', width:'fit-content' }}>
              {(['thresholds','themes','audit'] as const).map(t => (
                <button key={t} onClick={() => setSysTab(t)}
                  style={{ padding:'10px 18px', border:'none', background: sysTab===t ? '#111827' : '#fff', color: sysTab===t ? '#fff' : '#374151', cursor:'pointer', fontWeight: sysTab===t ? 700 : 500, fontSize:'0.78rem' }}>
                  {t==='thresholds' ? '⚙️ Thresholds' : t==='themes' ? '🎨 Temas' : '📋 Audit Log'}
                </button>
              ))}
            </div>

            {sysTab === 'thresholds' && <SystemThresholds/>}
            {sysTab === 'themes'     && <SystemThemes/>}
            {sysTab === 'audit'      && <SystemAuditLog campaigns={campaigns}/>}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Builder Step wrapper ──────────────────────────────────────────────────────
function BuilderStep({ title, icon:Icon, children }: { title:string; icon:any; children:React.ReactNode }) {
  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', gap:'10px', marginBottom:'24px', paddingBottom:'16px', borderBottom:'1px solid #F3F4F6' }}>
        <div style={{ width:'36px', height:'36px', borderRadius:'8px', background:O+'15', display:'flex', alignItems:'center', justifyContent:'center' }}>
          <Icon size={17} color={O}/>
        </div>
        <h3 style={{ margin:0, fontWeight:800, color:'#111827', fontSize:'1rem' }}>{title}</h3>
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:'18px' }}>{children}</div>
    </div>
  );
}

// ─── Field Row ─────────────────────────────────────────────────────────────────
function FieldRow({ label, required, children }: { label:string; required?:boolean; children:React.ReactNode }) {
  return (
    <div>
      <label style={{ display:'block', fontSize:'0.75rem', fontWeight:700, color:'#374151', marginBottom:'6px', letterSpacing:'0.03em' }}>
        {label}{required && <span style={{ color:O }}> *</span>}
      </label>
      {children}
    </div>
  );
}

const inputStyle: React.CSSProperties = {
  width:'100%', padding:'9px 12px', border:'1px solid #E5E7EB', borderRadius:'7px',
  fontSize:'0.82rem', outline:'none', boxSizing:'border-box', background:'#fff', color:'#111827',
};

// ─── Reward Row ────────────────────────────────────────────────────────────────
function RewardRow({ reward, idx, onUpdate, onRemove }: { reward:Reward; idx:number; onUpdate:(i:number,f:keyof Reward,v:any)=>void; onRemove:(i:number)=>void }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ border:'1px solid #E5E7EB', borderRadius:'8px', overflow:'hidden' }}>
      <div style={{ display:'flex', alignItems:'center', gap:'10px', padding:'10px 14px', background:'#F9FAFB', cursor:'pointer' }} onClick={()=>setOpen(o=>!o)}>
        <input value={reward.icon} onChange={e=>onUpdate(idx,'icon',e.target.value)}
          onClick={e=>e.stopPropagation()}
          style={{ width:'36px', padding:'4px', border:'1px solid #E5E7EB', borderRadius:'5px', fontSize:'1rem', textAlign:'center', background:'#fff' }}/>
        <input value={reward.name} onChange={e=>onUpdate(idx,'name',e.target.value)}
          onClick={e=>e.stopPropagation()}
          placeholder="Nombre del reward"
          style={{ flex:1, padding:'6px 9px', border:'1px solid #E5E7EB', borderRadius:'5px', fontSize:'0.82rem', background:'#fff', color:'#111827' }}/>
        <span style={{ fontSize:'0.72rem', color: Math.abs(reward.probability_weight) > 0 ? '#374151' : '#9CA3AF', fontWeight:700, minWidth:'36px', textAlign:'right' }}>
          {reward.probability_weight}%
        </span>
        <span style={{ fontSize:'0.7rem', padding:'2px 8px', borderRadius:'20px', background:TIER_CFG[reward.tier].color+'18', color:TIER_CFG[reward.tier].color, fontWeight:700 }}>
          {reward.tier}
        </span>
        {open ? <ChevronUp size={14} color="#9CA3AF"/> : <ChevronDown size={14} color="#9CA3AF"/>}
        <button onClick={e=>{e.stopPropagation();onRemove(idx);}}
          style={{ background:'none', border:'none', cursor:'pointer', color:'#EF4444', padding:'2px' }}>
          <Trash2 size={13}/>
        </button>
      </div>
      {open && (
        <div style={{ padding:'14px', display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'12px', background:'#fff', borderTop:'1px solid #F3F4F6' }}>
          <FieldRow label="Descripción">
            <input value={reward.description} onChange={e=>onUpdate(idx,'description',e.target.value)} style={inputStyle} placeholder="Breve descripción"/>
          </FieldRow>
          <FieldRow label="Tier">
            <select value={reward.tier} onChange={e=>onUpdate(idx,'tier',e.target.value)} style={inputStyle}>
              <option value="standard">Standard</option>
              <option value="premium">Premium</option>
              <option value="special">Special</option>
            </select>
          </FieldRow>
          <FieldRow label="Peso de probabilidad (%)">
            <input type="number" min={0} max={100} value={reward.probability_weight} onChange={e=>onUpdate(idx,'probability_weight',+e.target.value)} style={inputStyle}/>
          </FieldRow>
          <FieldRow label="Stock límite (0=ilimitado)">
            <input type="number" min={0} value={reward.stock_limit} onChange={e=>onUpdate(idx,'stock_limit',+e.target.value)} style={inputStyle}/>
          </FieldRow>
          <FieldRow label="Costo estimado ($)">
            <input type="number" min={0} step={0.01} value={reward.cost_estimate} onChange={e=>onUpdate(idx,'cost_estimate',+e.target.value)} style={inputStyle}/>
          </FieldRow>
          <FieldRow label="Categoría asociada">
            <input value={reward.associated_category} onChange={e=>onUpdate(idx,'associated_category',e.target.value)} style={inputStyle} placeholder="general"/>
          </FieldRow>
          <div style={{ display:'flex', alignItems:'center', gap:'8px' }}>
            <button onClick={()=>onUpdate(idx,'requires_manual_review',!reward.requires_manual_review)}
              style={{ background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', gap:'6px', color:'#374151', fontSize:'0.78rem', fontWeight:600 }}>
              {reward.requires_manual_review ? <ToggleRight size={18} color={O}/> : <ToggleLeft size={18} color="#9CA3AF"/>}
              Requiere revisión manual
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Eligibility Editor ────────────────────────────────────────────────────────
function EligibilityEditor({ rules, onChange }: { rules:EligibilityRules; onChange:(r:EligibilityRules)=>void }) {
  const upd = (field: keyof EligibilityRules, value: any) => onChange({ ...rules, [field]: value });
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:'16px' }}>
      <FieldRow label="Operador lógico">
        <div style={{ display:'flex', gap:'8px' }}>
          {(['AND','OR'] as const).map(l => (
            <button key={l} onClick={()=>upd('logic',l)}
              style={{ flex:1, padding:'8px', border:`2px solid ${rules.logic===l ? O : '#E5E7EB'}`, borderRadius:'7px', background:rules.logic===l?O+'10':'#fff', cursor:'pointer', fontWeight:700, fontSize:'0.82rem', color:rules.logic===l?O:'#374151' }}>
              {l}
            </button>
          ))}
        </div>
      </FieldRow>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'14px' }}>
        <FieldRow label="Gasto mensual mínimo ($)">
          <input type="number" min={0} value={rules.minimum_monthly_spend} onChange={e=>upd('minimum_monthly_spend',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="Multiplicador de gasto">
          <input type="number" min={0.1} step={0.1} value={rules.monthly_spend_multiplier} onChange={e=>upd('monthly_spend_multiplier',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="Diversidad de categorías mínima">
          <input type="number" min={0} value={rules.minimum_category_diversity} onChange={e=>upd('minimum_category_diversity',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="Score de usuario mínimo">
          <input type="number" min={0} max={100} value={rules.user_score_threshold} onChange={e=>upd('user_score_threshold',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="Compras mínimas">
          <input type="number" min={0} value={rules.purchase_count_threshold} onChange={e=>upd('purchase_count_threshold',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="Flag de comportamiento personalizado">
          <input value={rules.custom_behavior_flag??''} onChange={e=>upd('custom_behavior_flag',e.target.value||null)} style={inputStyle} placeholder="null (opcional)"/>
        </FieldRow>
      </div>
      <FieldRow label="">
        <button onClick={()=>upd('activation_conversion_required',!rules.activation_conversion_required)}
          style={{ background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', gap:'8px', color:'#374151', fontSize:'0.82rem', fontWeight:600 }}>
          {rules.activation_conversion_required ? <ToggleRight size={20} color={O}/> : <ToggleLeft size={20} color="#9CA3AF"/>}
          Requiere conversión de activación previa
        </button>
      </FieldRow>
    </div>
  );
}

// ─── Economic Editor ───────────────────────────────────────────────────────────
function EconomicEditor({ economic, rewards, onChange }: { economic:Economic; rewards:Reward[]; onChange:(e:Economic)=>void }) {
  const upd = (f: keyof Economic, v: any) => onChange({ ...economic, [f]: v });
  const totalW = rewards.reduce((s,r) => s+(r.probability_weight??0), 0) || 1;
  const projCost1000 = rewards.reduce((total,r) => {
    return total + 1000 * 0.75 * ((r.probability_weight??0)/totalW) * (r.cost_estimate??0);
  }, 0);
  const riskPct = economic.budget_limit > 0 ? (projCost1000 / economic.budget_limit) * 100 : 0;
  const riskColor = riskPct > 100 ? '#DC2626' : riskPct > 80 ? '#D97706' : '#16A34A';

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:'18px' }}>
      <div style={{ background: riskPct > 100 ? '#FEF2F2' : riskPct > 80 ? '#FFFBEB' : '#F0FDF4', border:`1px solid ${riskColor}40`, borderRadius:'10px', padding:'16px' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'8px' }}>
          <span style={{ fontWeight:700, color:'#374151', fontSize:'0.85rem' }}>Risk Exposure (1000 spins estimados)</span>
          <span style={{ fontWeight:800, fontSize:'1.1rem', color:riskColor }}>${projCost1000.toFixed(0)}</span>
        </div>
        <div style={{ height:'6px', background:'#E5E7EB', borderRadius:'3px', overflow:'hidden' }}>
          <div style={{ width:`${Math.min(riskPct,100)}%`, height:'100%', background:riskColor, borderRadius:'3px' }}/>
        </div>
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.68rem', color:'#6B7280', marginTop:'4px' }}>
          <span>{riskPct.toFixed(0)}% del presupuesto</span>
          <span>Presupuesto: ${economic.budget_limit}</span>
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'14px' }}>
        <FieldRow label="Presupuesto límite ($)">
          <input type="number" min={0} value={economic.budget_limit} onChange={e=>upd('budget_limit',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="Tasa de redención esperada (0-1)">
          <input type="number" min={0} max={1} step={0.05} value={economic.expected_redemption_rate} onChange={e=>upd('expected_redemption_rate',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="Umbral de alerta por desvío (%)">
          <input type="number" min={1} max={100} value={economic.deviation_alert_threshold} onChange={e=>upd('deviation_alert_threshold',+e.target.value)} style={inputStyle}/>
        </FieldRow>
        <FieldRow label="">
          <button onClick={()=>upd('auto_stop_enabled',!economic.auto_stop_enabled)}
            style={{ background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', gap:'8px', color:'#374151', fontSize:'0.82rem', fontWeight:600, paddingTop:'22px' }}>
            {economic.auto_stop_enabled ? <ToggleRight size={20} color={O}/> : <ToggleLeft size={20} color="#9CA3AF"/>}
            Auto-stop al agotar presupuesto
          </button>
        </FieldRow>
      </div>
    </div>
  );
}

// ─── Campaign Summary ──────────────────────────────────────────────────────────
function CampaignSummary({ campaign }: { campaign: Partial<Campaign> }) {
  const theme = campaign.theme_id ? THEMES[campaign.theme_id] : THEMES.dark_gold;
  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px', fontSize:'0.82rem' }}>
      {[
        ['Nombre',    campaign.name || '—'],
        ['Tipo',      campaign.campaign_type ?? '—'],
        ['Tema',      theme.name],
        ['Frecuencia',campaign.frequency ?? '—'],
        ['Visibilidad',campaign.visibility ?? '—'],
        ['Max spins', String(campaign.max_spins_per_user ?? 1)],
        ['Rewards',   String((campaign.rewards??[]).length) + ' segmentos'],
        ['Presupuesto','$' + String(campaign.economic?.budget_limit ?? 5000)],
      ].map(([k,v]) => (
        <div key={k} style={{ padding:'10px 14px', background:'#F9FAFB', borderRadius:'7px' }}>
          <div style={{ fontSize:'0.67rem', color:'#9CA3AF', fontWeight:700, textTransform:'uppercase', letterSpacing:'0.06em', marginBottom:'3px' }}>{k}</div>
          <div style={{ fontWeight:600, color:'#111827' }}>{v}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Validation Result ─────────────────────────────────────────────────────────
function ValidationResult({ result }: { result: any }) {
  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'10px' }}>
        {result.valid
          ? <><CheckCircle size={16} color="#16A34A"/><span style={{ fontWeight:700, color:'#16A34A', fontSize:'0.82rem' }}>Listo para activar</span></>
          : <><XCircle    size={16} color="#DC2626"/><span style={{ fontWeight:700, color:'#DC2626', fontSize:'0.82rem' }}>{result.errors?.length} error(es) encontrado(s)</span></>
        }
      </div>
      {result.errors?.map((e:string,i:number) => (
        <div key={i} style={{ display:'flex', gap:'6px', padding:'6px 10px', background:'#FEF2F2', borderRadius:'6px', marginBottom:'4px', fontSize:'0.75rem', color:'#DC2626' }}>
          <XCircle size={12} style={{flexShrink:0,marginTop:'1px'}}/> {e}
        </div>
      ))}
      {result.warnings?.map((w:string,i:number) => (
        <div key={i} style={{ display:'flex', gap:'6px', padding:'6px 10px', background:'#FFFBEB', borderRadius:'6px', marginBottom:'4px', fontSize:'0.75rem', color:'#D97706' }}>
          <AlertTriangle size={12} style={{flexShrink:0,marginTop:'1px'}}/> {w}
        </div>
      ))}
      {result.projected_cost != null && (
        <div style={{ marginTop:'8px', fontSize:'0.75rem', color:'#374151' }}>
          Costo proyectado: <b>${result.projected_cost?.toFixed(0)}</b> · Utilización: <b>{result.budget_utilization?.toFixed(1)}%</b>
        </div>
      )}
    </div>
  );
}

// ─── Simulation Result ─────────────────────────────────────────────────────────
function SimulationResult({ result }: { result: any }) {
  const riskColor = result.risk_level === 'high' ? '#DC2626' : result.risk_level === 'medium' ? '#D97706' : '#16A34A';
  return (
    <div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'10px', marginBottom:'14px' }}>
        {[
          { label:'Spins efectivos', value: String(result.effective_spins) },
          { label:'Costo proyectado', value: '$' + result.projected_cost?.toFixed(0) },
          { label:'Utilización presupuesto', value: result.budget_utilization_pct?.toFixed(1) + '%' },
        ].map((k,i) => (
          <div key={i} style={{ padding:'10px', background:'#fff', border:'1px solid #E5E7EB', borderRadius:'7px', textAlign:'center' }}>
            <div style={{ fontSize:'0.65rem', color:'#9CA3AF', fontWeight:700, textTransform:'uppercase', marginBottom:'3px' }}>{k.label}</div>
            <div style={{ fontWeight:800, color:'#111827', fontSize:'1rem' }}>{k.value}</div>
          </div>
        ))}
      </div>
      <div style={{ padding:'6px 12px', background:riskColor+'12', border:`1px solid ${riskColor}30`, borderRadius:'6px', display:'inline-block', marginBottom:'12px', fontSize:'0.72rem', fontWeight:700, color:riskColor }}>
        Riesgo: {result.risk_level?.toUpperCase()}
      </div>
      <div style={{ border:'1px solid #E5E7EB', borderRadius:'8px', overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:'0.75rem' }}>
          <thead>
            <tr style={{ background:'#F9FAFB' }}>
              {['Reward','Peso','Activaciones esp.','Costo esp.'].map(h=>(
                <th key={h} style={{ padding:'8px 12px', textAlign:'left', fontWeight:700, color:'#374151', fontSize:'0.68rem', textTransform:'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {result.reward_breakdown?.map((r:any,i:number) => (
              <tr key={i} style={{ borderTop:'1px solid #F3F4F6' }}>
                <td style={{ padding:'8px 12px', fontWeight:600, color:'#111827' }}>{r.name}</td>
                <td style={{ padding:'8px 12px', color:'#6B7280' }}>{r.weight_pct}%</td>
                <td style={{ padding:'8px 12px', color:'#374151' }}>{r.expected_activations}</td>
                <td style={{ padding:'8px 12px', fontWeight:700, color:'#374151' }}>${r.expected_cost?.toFixed(0)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── System Admin sub-panels ───────────────────────────────────────────────────
function SystemThresholds() {
  const [vals, setVals] = useState({ max_budget: 50000, max_rewards: 16, max_spins: 10, global_auto_stop: true, override_requires_confirm: true });
  return (
    <div style={{ background:'#fff', border:'1px solid #E5E7EB', borderRadius:'12px', padding:'24px 28px' }}>
      <h3 style={{ margin:'0 0 20px', fontWeight:800, color:'#111827' }}>Thresholds Globales del Sistema</h3>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'16px' }}>
        {[
          { label:'Presupuesto máximo por campaña ($)', key:'max_budget', type:'number' },
          { label:'Máx. rewards por campaña',           key:'max_rewards', type:'number' },
          { label:'Máx. spins por usuario por ciclo',   key:'max_spins', type:'number' },
        ].map(({label,key,type}) => (
          <FieldRow key={key} label={label}>
            <input type={type} value={(vals as any)[key]} onChange={e=>setVals(p=>({...p,[key]:+e.target.value}))} style={inputStyle}/>
          </FieldRow>
        ))}
        <div style={{ display:'flex', flexDirection:'column', gap:'12px', paddingTop:'4px' }}>
          {[
            { key:'global_auto_stop', label:'Auto-stop global habilitado' },
            { key:'override_requires_confirm', label:'Override económico requiere confirmación' },
          ].map(({key,label}) => (
            <button key={key} onClick={()=>setVals(p=>({...p,[key]:!(p as any)[key]}))}
              style={{ background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', gap:'8px', color:'#374151', fontSize:'0.82rem', fontWeight:600 }}>
              {(vals as any)[key] ? <ToggleRight size={20} color={O}/> : <ToggleLeft size={20} color="#9CA3AF"/>}
              {label}
            </button>
          ))}
        </div>
      </div>
      <div style={{ marginTop:'20px', paddingTop:'20px', borderTop:'1px solid #F3F4F6', display:'flex', justifyContent:'flex-end' }}>
        <button onClick={() => alert('Configuración guardada (demo)')}
          style={{ padding:'9px 20px', background:'#111827', color:'#fff', border:'none', borderRadius:'8px', cursor:'pointer', fontWeight:700, fontSize:'0.82rem' }}>
          Guardar configuración del sistema
        </button>
      </div>
    </div>
  );
}

function SystemThemes() {
  return (
    <div style={{ background:'#fff', border:'1px solid #E5E7EB', borderRadius:'12px', padding:'24px 28px' }}>
      <h3 style={{ margin:'0 0 20px', fontWeight:800, color:'#111827' }}>Catálogo de Temas Permitidos</h3>
      <p style={{ margin:'0 0 20px', color:'#6B7280', fontSize:'0.82rem' }}>
        Los temas son controlados por System Admin. No se permiten colores arbitrarios en campañas.
        Gateway puede usar cualquier tema. Privilege queda restringido a temas sobrios.
      </p>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:'14px' }}>
        {(Object.entries(THEMES) as [ThemeId, typeof THEMES[ThemeId]][]).map(([id, t]) => (
          <div key={id} style={{ border:'1px solid #E5E7EB', borderRadius:'10px', overflow:'hidden' }}>
            <div style={{ height:'60px', background:t.bg, position:'relative' }}>
              <div style={{ position:'absolute', bottom:'8px', left:'12px', right:'12px', height:'2px', background:t.accent, borderRadius:'1px' }}/>
            </div>
            <div style={{ padding:'12px 14px' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontWeight:700, color:'#111827', fontSize:'0.85rem' }}>{t.name}</span>
                <code style={{ fontSize:'0.68rem', color:t.accent, background:t.accent+'18', padding:'2px 8px', borderRadius:'4px' }}>{id}</code>
              </div>
              <div style={{ fontSize:'0.72rem', color:'#6B7280', marginTop:'4px' }}>Acento: {t.accent}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SystemAuditLog({ campaigns }: { campaigns: Campaign[] }) {
  const allLogs = campaigns.flatMap(c =>
    (c.audit_log ?? []).map(e => ({ ...e, campaign_name: c.name, campaign_id: c.id }))
  ).sort((a,b) => new Date(b.at).getTime() - new Date(a.at).getTime()).slice(0, 50);

  const actionColor: Record<string,string> = {
    created:'#2563EB', updated:'#6B7280', activated:'#16A34A', archived:'#374151',
    version_bump:'#D97706', auto_stopped:'#DC2626',
  };

  return (
    <div style={{ background:'#fff', border:'1px solid #E5E7EB', borderRadius:'12px', overflow:'hidden' }}>
      <div style={{ padding:'16px 20px', borderBottom:'1px solid #F3F4F6', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <h3 style={{ margin:0, fontWeight:800, color:'#111827' }}>Audit Log</h3>
        <span style={{ fontSize:'0.72rem', color:'#9CA3AF' }}>Últimas {allLogs.length} entradas</span>
      </div>
      {allLogs.length === 0 ? (
        <div style={{ padding:'40px', textAlign:'center', color:'#9CA3AF', fontSize:'0.82rem' }}>Sin registros de auditoría</div>
      ) : (
        <div style={{ maxHeight:'500px', overflowY:'auto' }}>
          {allLogs.map((e,i) => (
            <div key={i} style={{ display:'flex', gap:'14px', padding:'12px 20px', borderBottom:'1px solid #F9FAFB', alignItems:'flex-start' }}>
              <div style={{ width:'8px', height:'8px', borderRadius:'50%', background:actionColor[e.action]??'#9CA3AF', marginTop:'5px', flexShrink:0 }}/>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', gap:'8px', alignItems:'center', flexWrap:'wrap' }}>
                  <span style={{ padding:'1px 8px', background:(actionColor[e.action]??'#9CA3AF')+'18', color:actionColor[e.action]??'#9CA3AF', borderRadius:'10px', fontSize:'0.65rem', fontWeight:700, textTransform:'uppercase' }}>{e.action}</span>
                  <span style={{ fontWeight:600, color:'#374151', fontSize:'0.78rem' }}>{e.campaign_name}</span>
                  <span style={{ color:'#9CA3AF', fontSize:'0.68rem', marginLeft:'auto' }}>{new Date(e.at).toLocaleString('es-AR')}</span>
                </div>
                <div style={{ fontSize:'0.75rem', color:'#6B7280', marginTop:'3px' }}>{e.note}</div>
                <div style={{ fontSize:'0.65rem', color:'#D1D5DB', marginTop:'2px', fontFamily:'monospace' }}>by {e.by} · {e.campaign_id}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
