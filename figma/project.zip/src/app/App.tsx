/* =====================================================
   Charlie Marketplace Builder v1.5
   App Root — React Router v7 Data Mode + AuthProvider
   ===================================================== */
import { RouterProvider } from 'react-router';
import { router } from './routes';
import { AuthProvider } from './components/auth/AuthContext';

export default function App() {
  return (
    <AuthProvider>
      <RouterProvider router={router} />
    </AuthProvider>
  );
}
