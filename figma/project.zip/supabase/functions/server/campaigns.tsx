/* =====================================================
   Campaign Engine — Charlie Marketplace Builder v1.5
   ===================================================== */
import { Hono } from "npm:hono";
import * as kv from "./kv_store.tsx";

const campaigns = new Hono();

// ─── KV Keys ──────────────────────────────────────────────────────────────────
// All campaign records share the prefix "campaign_75638143_" (singular, no 's')
// so getByPrefix("campaign_75638143_") returns exactly all campaigns.
const CAMP_PREFIX = "campaign_75638143_";
const campKey = (id: string): string => CAMP_PREFIX + id;

// ─── ID generators ────────────────────────────────────────────────────────────
function genId(): string {
  return "camp_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
}

function genRid(): string {
  return "rew_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 4);
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
async function getAllCampaigns(): Promise<any[]> {
  // Single DB query instead of N+1 — avoids concurrent client issues
  return await kv.getByPrefix(CAMP_PREFIX);
}

async function getCampaign(id: string): Promise<any> {
  return await kv.get(campKey(id));
}

function calcCost(camp: any, spinCount: number): number {
  const rewards: any[] = Array.isArray(camp.rewards) ? camp.rewards : [];
  if (rewards.length === 0) return 0;
  const rate = typeof camp.economic?.expected_redemption_rate === "number"
    ? camp.economic.expected_redemption_rate
    : 0.75;
  const spins = spinCount * rate;
  const totalW = rewards.reduce((s: number, r: any) => s + (Number(r.probability_weight) || 0), 0) || 1;
  return rewards.reduce((total: number, r: any) => {
    const share = (Number(r.probability_weight) || 0) / totalW;
    return total + spins * share * (Number(r.cost_estimate) || 0);
  }, 0);
}

function withAudit(camp: any, action: string, by: string, note: string): any {
  const entry = { action, at: new Date().toISOString(), by, note };
  const log: any[] = Array.isArray(camp.audit_log) ? camp.audit_log : [];
  return { ...camp, audit_log: [...log, entry] };
}

// ─── GET / — list all campaigns ───────────────────────────────────────────────
campaigns.get("/", async (c) => {
  try {
    const list: any[] = await getAllCampaigns();
    list.sort((a: any, b: any) => {
      const ta = a.created_at ? new Date(a.created_at).getTime() : 0;
      const tb = b.created_at ? new Date(b.created_at).getTime() : 0;
      return tb - ta;
    });
    return c.json(list);
  } catch (err) {
    console.log("campaigns GET / error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── GET /active/:type — get the active campaign for gateway|privilege ─────────
campaigns.get("/active/:type", async (c) => {
  try {
    const type = c.req.param("type");
    const all: any[] = await getAllCampaigns();
    const found = all.find((x: any) => x.status === "active" && x.campaign_type === type);
    if (!found) return c.json({ error: "No active campaign found for type: " + type }, 404);
    return c.json(found);
  } catch (err) {
    console.log("campaigns GET /active/:type error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── GET /:id ─────────────────────────────────────────────────────────────────
campaigns.get("/:id", async (c) => {
  try {
    const camp = await getCampaign(c.req.param("id"));
    if (!camp) return c.json({ error: "Campaign not found" }, 404);
    return c.json(camp);
  } catch (err) {
    console.log("campaigns GET /:id error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── POST / — create ──────────────────────────────────────────────────────────
campaigns.post("/", async (c) => {
  try {
    const body = await c.req.json();
    const id = genId();
    const now = new Date().toISOString();

    const rawRewards: any[] = Array.isArray(body.rewards) ? body.rewards : [];
    const rewards = rawRewards.map((r: any) => ({
      ...r,
      reward_id: r.reward_id || genRid(),
      stock_remaining: Number(r.stock_limit) || 0,
    }));

    const camp: any = {
      id,
      name: String(body.name || "Nueva Campaña"),
      campaign_type: body.campaign_type === "privilege" ? "privilege" : "gateway",
      status: "draft",
      start_date: body.start_date || null,
      end_date: body.end_date || null,
      next_activation_date: body.next_activation_date || null,
      frequency: body.frequency || "monthly",
      max_spins_per_user: Number(body.max_spins_per_user) || 1,
      visibility: body.visibility === "hidden_unlock" ? "hidden_unlock" : "public",
      version: 1,
      theme_id: body.theme_id || "dark_gold",
      rewards,
      eligibility_rules: body.eligibility_rules || null,
      economic: body.economic || {
        budget_limit: 5000,
        projected_cost: 0,
        expected_redemption_rate: 0.75,
        deviation_alert_threshold: 20,
        auto_stop_enabled: true,
      },
      created_at: now,
      updated_at: now,
      created_by: body.created_by || "admin",
      audit_log: [{ action: "created", at: now, by: body.created_by || "admin", note: "Campaña creada" }],
    };

    await kv.set(campKey(id), camp);
    return c.json(camp, 201);
  } catch (err) {
    console.log("campaigns POST / error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── PATCH /:id — update (bumps version if active) ───────────────────────────
campaigns.patch("/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const camp = await getCampaign(id);
    if (!camp) return c.json({ error: "Campaign not found" }, 404);

    const body = await c.req.json();
    const now = new Date().toISOString();
    const wasActive = camp.status === "active";
    const newVersion = wasActive ? (Number(camp.version) || 1) + 1 : (Number(camp.version) || 1);

    const rewards = Array.isArray(body.rewards)
      ? (body.rewards as any[]).map((r: any) => ({
          ...r,
          reward_id: r.reward_id || genRid(),
          stock_remaining: r.stock_remaining !== undefined ? r.stock_remaining : (Number(r.stock_limit) || 0),
        }))
      : camp.rewards;

    const merged: any = { ...camp, ...body, id, rewards, version: newVersion, updated_at: now };
    const note = wasActive
      ? "Nueva versión v" + newVersion + " creada tras edición en campaña activa"
      : "Campaña actualizada";
    const updated = withAudit(merged, wasActive ? "version_bump" : "updated", body.updated_by || "admin", note);

    await kv.set(campKey(id), updated);
    return c.json(updated);
  } catch (err) {
    console.log("campaigns PATCH /:id error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── POST /:id/validate ───────────────────────────────────────────────────────
campaigns.post("/:id/validate", async (c) => {
  try {
    const camp = await getCampaign(c.req.param("id"));
    if (!camp) return c.json({ error: "Campaign not found" }, 404);

    const errors: string[] = [];
    const warnings: string[] = [];
    const rewards: any[] = Array.isArray(camp.rewards) ? camp.rewards : [];

    if (rewards.length === 0) errors.push("Debe tener al menos 1 reward configurado.");

    const totalW = rewards.reduce((s: number, r: any) => s + (Number(r.probability_weight) || 0), 0);
    if (totalW === 0) {
      errors.push("Los pesos de probabilidad deben sumar al menos 1.");
    } else if (Math.abs(totalW - 100) > 1) {
      warnings.push("Pesos suman " + totalW + "% — recomendado 100%.");
    }

    if (!camp.start_date) warnings.push("Sin fecha de inicio definida.");
    if (!camp.end_date) warnings.push("Sin fecha de fin definida.");

    const all: any[] = await getAllCampaigns();
    const conflict = all.find((x: any) => x.id !== camp.id && x.status === "active" && x.campaign_type === camp.campaign_type);
    if (conflict) errors.push("Ya existe la campaña \"" + conflict.name + "\" activa para tipo " + camp.campaign_type + ".");

    const projectedCost = calcCost(camp, 1000);
    const budgetLimit = Number(camp.economic?.budget_limit) || 5000;
    if (projectedCost > budgetLimit) {
      errors.push("Costo proyectado ($" + projectedCost.toFixed(0) + ") excede el presupuesto ($" + budgetLimit + ").");
    } else if (projectedCost > budgetLimit * 0.85) {
      warnings.push("Costo proyectado ($" + projectedCost.toFixed(0) + ") supera el 85% del presupuesto.");
    }

    return c.json({
      valid: errors.length === 0,
      errors,
      warnings,
      projected_cost: projectedCost,
      budget_utilization: budgetLimit > 0 ? (projectedCost / budgetLimit) * 100 : 0,
    });
  } catch (err) {
    console.log("campaigns POST /:id/validate error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── POST /:id/activate ───────────────────────────────────────────────────────
campaigns.post("/:id/activate", async (c) => {
  try {
    const id = c.req.param("id");
    const camp = await getCampaign(id);
    if (!camp) return c.json({ error: "Campaign not found" }, 404);

    const rewards: any[] = Array.isArray(camp.rewards) ? camp.rewards : [];
    if (rewards.length === 0) return c.json({ error: "No se puede activar sin rewards." }, 400);

    const all: any[] = await getAllCampaigns();
    const conflict = all.find((x: any) => x.id !== id && x.status === "active" && x.campaign_type === camp.campaign_type);
    if (conflict) return c.json({ error: "Conflicto: \"" + conflict.name + "\" ya está activa para tipo " + camp.campaign_type + "." }, 409);

    const projectedCost = calcCost(camp, 1000);
    const budgetLimit = Number(camp.economic?.budget_limit) || 5000;

    let override = false;
    try {
      const body = await c.req.json();
      if (body && body.override === true) override = true;
    } catch (_ignore) {
      // no body or invalid JSON
    }

    if (projectedCost > budgetLimit && !override) {
      return c.json({
        error: "Costo proyectado ($" + projectedCost.toFixed(0) + ") excede presupuesto. Se requiere override de System Admin.",
        requires_override: true,
      }, 400);
    }

    const now = new Date().toISOString();
    const note = override ? "Activada con override de System Admin" : "Campaña activada";
    const updated = withAudit({ ...camp, status: "active", updated_at: now }, "activated", "admin", note);
    await kv.set(campKey(id), updated);
    return c.json(updated);
  } catch (err) {
    console.log("campaigns POST /:id/activate error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── POST /:id/archive ────────────────────────────────────────────────────────
campaigns.post("/:id/archive", async (c) => {
  try {
    const id = c.req.param("id");
    const camp = await getCampaign(id);
    if (!camp) return c.json({ error: "Campaign not found" }, 404);
    const now = new Date().toISOString();
    const updated = withAudit({ ...camp, status: "archived", updated_at: now }, "archived", "admin", "Archivada manualmente");
    await kv.set(campKey(id), updated);
    return c.json(updated);
  } catch (err) {
    console.log("campaigns POST /:id/archive error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── POST /:id/simulate ───────────────────────────────────────────────────────
campaigns.post("/:id/simulate", async (c) => {
  try {
    const camp = await getCampaign(c.req.param("id"));
    if (!camp) return c.json({ error: "Campaign not found" }, 404);

    let spins = 1000;
    try {
      const body = await c.req.json();
      if (body && typeof body.expected_spins === "number" && body.expected_spins > 0) {
        spins = body.expected_spins;
      }
    } catch (_ignore) {
      // use default spins
    }

    const rewards: any[] = Array.isArray(camp.rewards) ? camp.rewards : [];
    const rate = Number(camp.economic?.expected_redemption_rate) || 0.75;
    const effective = Math.round(spins * rate);
    const cost = calcCost(camp, spins);
    const budgetLimit = Number(camp.economic?.budget_limit) || 5000;
    const totalW = rewards.reduce((s: number, r: any) => s + (Number(r.probability_weight) || 0), 0) || 1;

    const breakdown = rewards.map((r: any) => {
      const pct = (Number(r.probability_weight) || 0) / totalW;
      const acts = Math.round(effective * pct);
      return {
        reward_id: r.reward_id,
        name: r.name,
        weight_pct: Math.round(pct * 100),
        expected_activations: acts,
        expected_cost: Math.round(acts * (Number(r.cost_estimate) || 0) * 100) / 100,
      };
    });

    const riskLevel = cost > budgetLimit ? "high" : cost > budgetLimit * 0.8 ? "medium" : "low";

    return c.json({
      expected_spins: spins,
      effective_spins: effective,
      projected_cost: Math.round(cost * 100) / 100,
      budget_limit: budgetLimit,
      budget_utilization_pct: budgetLimit > 0 ? Math.round((cost / budgetLimit) * 100) : 0,
      risk_level: riskLevel,
      reward_breakdown: breakdown,
    });
  } catch (err) {
    console.log("campaigns POST /:id/simulate error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

// ─── POST /:id/spin — Activation Engine ───────────────────────────────────────
campaigns.post("/:id/spin", async (c) => {
  try {
    const id = c.req.param("id");
    const camp = await getCampaign(id);
    if (!camp) return c.json({ error: "Campaign not found" }, 404);
    if (camp.status !== "active") return c.json({ error: "Campaign is not active" }, 400);

    const rewards: any[] = Array.isArray(camp.rewards) ? camp.rewards : [];
    const available = rewards.filter((r: any) => {
      const stockLimit = Number(r.stock_limit) || 0;
      const stockRemaining = r.stock_remaining !== undefined ? Number(r.stock_remaining) : stockLimit;
      return stockLimit === 0 || stockRemaining > 0;
    });

    if (available.length === 0) return c.json({ error: "No rewards available (stock exhausted)" }, 400);

    // Weighted random
    const totalW = available.reduce((s: number, r: any) => s + (Number(r.probability_weight) || 0), 0);
    let rand = Math.random() * totalW;
    let winner = available[available.length - 1];
    for (let i = 0; i < available.length; i++) {
      rand -= Number(available[i].probability_weight) || 0;
      if (rand <= 0) {
        winner = available[i];
        break;
      }
    }

    const now = new Date().toISOString();

    // Reduce stock
    const updatedRewards = rewards.map((r: any) => {
      if (r.reward_id !== winner.reward_id) return r;
      if ((Number(r.stock_limit) || 0) === 0) return r; // unlimited
      const cur = r.stock_remaining !== undefined ? Number(r.stock_remaining) : Number(r.stock_limit);
      return { ...r, stock_remaining: Math.max(0, cur - 1) };
    });

    const prevCost = Number(camp.economic?.projected_cost) || 0;
    const newCost = prevCost + (Number(winner.cost_estimate) || 0);
    const budgetLimit = Number(camp.economic?.budget_limit) || 5000;
    const autoStop = camp.economic?.auto_stop_enabled === true && newCost >= budgetLimit;

    const next: any = {
      ...camp,
      rewards: updatedRewards,
      updated_at: now,
      economic: camp.economic ? { ...camp.economic, projected_cost: newCost } : camp.economic,
    };

    const final = autoStop
      ? withAudit({ ...next, status: "archived" }, "auto_stopped", "system",
          "Auto-stop: costo acumulado $" + newCost.toFixed(2) + " >= presupuesto $" + budgetLimit)
      : next;

    await kv.set(campKey(id), final);

    const winnerIndex = rewards.findIndex((r: any) => r.reward_id === winner.reward_id);

    return c.json({
      winner,
      winner_index: winnerIndex,
      campaign_id: id,
      spin_at: now,
      requires_manual_review: winner.requires_manual_review === true,
      auto_stopped: autoStop,
    });
  } catch (err) {
    console.log("campaigns POST /:id/spin error:", String(err));
    return c.json({ error: String(err) }, 500);
  }
});

export { campaigns };