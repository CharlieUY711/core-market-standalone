/* =====================================================
   Auth Handler — Registro + gestión de usuarios
   Charlie Marketplace Builder v1.5
   ===================================================== */
import { Hono } from "npm:hono";
import { createClient } from "npm:@supabase/supabase-js";

const auth = new Hono();

const getSupabaseAdmin = () =>
  createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

// ── POST /auth/signup ──────────────────────────────────────────────
// Crea un usuario nuevo con email confirmado automáticamente.
auth.post("/signup", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, name } = body;

    if (!email || !password) {
      return c.json({ error: "Email y contraseña son requeridos" }, 400);
    }
    if (password.length < 6) {
      return c.json({ error: "La contraseña debe tener al menos 6 caracteres" }, 400);
    }

    const supabase = getSupabaseAdmin();

    // Verificar si el email ya existe
    const { data: existing } = await supabase
      .from("auth.users")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: {
        name: name?.trim() || email.split("@")[0],
        full_name: name?.trim() || email.split("@")[0],
      },
      // Confirmar email automáticamente (sin servidor de email configurado)
      email_confirm: true,
    });

    if (error) {
      console.log("Error creando usuario:", error);
      // Mensaje amigable para errores comunes
      if (error.message?.includes("already registered") || error.message?.includes("already exists")) {
        return c.json({ error: "Este email ya está registrado. Intentá iniciar sesión." }, 409);
      }
      return c.json({ error: `Error al crear usuario: ${error.message}` }, 500);
    }

    console.log("Usuario creado exitosamente:", data.user?.id);
    return c.json({
      data: {
        user: {
          id: data.user?.id,
          email: data.user?.email,
          name: data.user?.user_metadata?.name,
        },
      },
    });
  } catch (err) {
    console.log("Error inesperado en signup:", err);
    return c.json({ error: `Error inesperado: ${err}` }, 500);
  }
});

// ── GET /auth/users ────────────────────────────────────────────────
// Lista usuarios (solo admin). Requiere Authorization.
auth.get("/users", async (c) => {
  try {
    const accessToken = c.req.header("Authorization")?.split(" ")[1];
    if (!accessToken) return c.json({ error: "No autorizado" }, 401);

    const supabase = getSupabaseAdmin();
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    if (authError || !user) return c.json({ error: "Token inválido" }, 401);

    const { data, error } = await supabase.auth.admin.listUsers();
    if (error) throw error;

    return c.json({
      data: data.users.map(u => ({
        id: u.id,
        email: u.email,
        name: u.user_metadata?.name || u.user_metadata?.full_name,
        created_at: u.created_at,
        last_sign_in_at: u.last_sign_in_at,
        email_confirmed_at: u.email_confirmed_at,
      })),
    });
  } catch (err) {
    console.log("Error listando usuarios:", err);
    return c.json({ error: `Error listando usuarios: ${err}` }, 500);
  }
});

export { auth };
